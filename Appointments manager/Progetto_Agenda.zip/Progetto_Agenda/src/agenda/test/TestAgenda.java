package agenda.test;

import static org.junit.Assert.*;

import java.util.TreeSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import agenda.Agenda;
import agenda.Appuntamento;
import agenda.Luogo;
import agenda.exception.AppuntamentoBadFormatException;
import agenda.exception.LuogoBadFormatException;

public class TestAgenda {

	private Agenda agenda = null;
	private Appuntamento a=null,b=null,c=null;
	private Luogo luogoA=null, luogoB=null, luogoC=null;
	private TreeSet<Appuntamento> appuntamenti=null;
	
	
	@Before
	public void init() {
		assertTrue(luogoA==null);
		try {
			luogoA = new Luogo("Novi Ligure, Via Verdi 24");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoA!=null);
		
		assertTrue(luogoB==null);
		try {
			luogoB = new Luogo("Alessandria, Via Roma 88");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoB!=null);
		
		assertTrue(luogoC==null);
		try {
			luogoC = new Luogo("Torino, Via Inganni 50");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoC!=null);
		try {
			a = new Appuntamento("Marco Rossi",luogoA, "12-05-2019","23:44", 24);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
		try {
			b = new Appuntamento("Giuseppe Verdi", luogoB, "02-06-2018", "23:30", 15);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
		try {
			c = new Appuntamento("Maria Bianchi", luogoC, "12-06-2019", "22:10", 79);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
		appuntamenti = new TreeSet<Appuntamento>();
		assertTrue(appuntamenti!=null);
		agenda = new Agenda();
		assertTrue(agenda!=null);
		agenda.setNome("Agenda 1");
		assertEquals("Agenda 1",agenda.getNome());
		agenda.setAppuntamenti(appuntamenti);
		assertEquals(appuntamenti,agenda.getAppuntamenti());
		
	}
	
	@After
	public void reset() {
		luogoA = null;
		assertTrue(luogoA==null);
		luogoB = null;
		assertTrue(luogoB==null);
		luogoC = null;
		assertTrue(luogoC==null);
		a = null;
		assertTrue(a==null);
		b = null;
		assertTrue(b==null);
		c = null;
		assertTrue(c==null);
		appuntamenti = null;
		assertTrue(appuntamenti==null);
		agenda = null;
		assertTrue(agenda==null);
	}
	
	
	@Test
	public void testInserimentoAppuntamenti() {
		assertEquals("Il numero di appuntamenti è pari a 0 inizialmente", 0,appuntamenti.size());
		assertEquals("L'inserimento di a ha successo", true,agenda.inserisciAppuntamento(a));
		assertEquals("Il numero di appuntamenti ora è 1", 1,agenda.getAppuntamenti().size());
		Appuntamento d = null;
		try {
			d = new Appuntamento("Giovanni Rossi", luogoC, "12-05-2019","23:44", 15);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		assertEquals("L'inserimento di d fallisce perché ha la stessa data e ora del primo inserito", false,agenda.inserisciAppuntamento(d));
		assertEquals("Il numero di appuntamenti è ancora 1", 1,agenda.getAppuntamenti().size());
		assertEquals("L'inserimento di b ha successo", true,agenda.inserisciAppuntamento(b));
		assertEquals("Il numero di appuntamenti ora è 2", 2,agenda.getAppuntamenti().size());
		assertEquals("L'inserimento di c ha successo", true,agenda.inserisciAppuntamento(c));
		assertEquals("Il numero di appuntamenti ora è 3", 3,agenda.getAppuntamenti().size());
		Appuntamento e = null;
		try {
			e = new Appuntamento("Marco Rossi",luogoA, "05-10-2019","23:44", 24);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		assertEquals("L'inserimento di e ha successo perché la data è diversa dall'appuntamento a", true,agenda.inserisciAppuntamento(e));
		assertEquals("Il numero di appuntamenti ora è 4", 4,agenda.getAppuntamenti().size());
		Appuntamento f = null;
		try {
			f = new Appuntamento("Marco Rossi",luogoA, "12-05-2019","23:41", 24);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		assertEquals("L'inserimento di f ha successo perché c'è sovrapposizione con l'appuntamento a", false,agenda.inserisciAppuntamento(f));
		assertEquals("Il numero di appuntamenti è ancora 4", 4,agenda.getAppuntamenti().size());
		Appuntamento g = null;
		try {
			g = new Appuntamento("Marco Rossi",luogoA, "12-05-2019","00:41", 24);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		assertEquals("L'inserimento di g ha successo perché l'ora è diversa "
				+ "dall'ora dell'appuntamento a e non c'è sovrapposizione con altri appuntamenti", true,agenda.inserisciAppuntamento(g));
		assertEquals("Il numero di appuntamenti ora è 5", 5,agenda.getAppuntamenti().size());
	}
	
	@Test
	public void testCercaAppuntamentoPerDataOra() {
		
		testInserimentoAppuntamenti();
		
		// Test cercaAppuntamento per data e ora
		assertEquals("Cerco l'appuntamento con data 02-03-2019 13:00, "
				+ "mi aspetto null",null,agenda.cercaAppuntamento("02-03-2019", "13:00"));
		assertEquals("Cerco l'appuntamento con data 02-06-2018 13:00, "
				+ "mi aspetto null",null,agenda.cercaAppuntamento("02-06-2018", "13:00"));
		assertEquals("Cerco l'appuntamento con data 02-03-2019 23:30, "
				+ "mi aspetto null",null,agenda.cercaAppuntamento("02-03-2019", "23:30"));
		assertEquals("Cerco l'appuntamento con data 12-05-2019 23:44, "
				+ "mi aspetto la restituzione di a",a,agenda.cercaAppuntamento("12-05-2019", "23:44"));
		assertEquals("Cerco l'appuntamento con data 02-03-2019 13:00, "
				+ "mi aspetto la restituzione di b",b,agenda.cercaAppuntamento("02-06-2018", "23:30"));
		assertEquals("Cerco l'appuntamento con data 02-03-2019 13:00, "
				+ "mi aspetto la restituzione di c",c,agenda.cercaAppuntamento("12-06-2019", "22:10"));
	}
	
	@Test
	public void testCercaAppuntamentoPerPersona() {
		
		testInserimentoAppuntamenti();
		
		// Test cercaAppuntamento per nome
		assertEquals("Cerco l'appuntamento con persona=Maria, "
				+ "mi aspetto che l'arrayList di ritorno abbia dimensione 1",1,agenda.cercaAppuntamento("Maria").size());
		assertEquals("Cerco l'appuntamento con persona=Maria Bianchi, "
				+ "mi aspetto che contenga un appuntamento",1,agenda.cercaAppuntamento("Maria Bianchi").size());
		Appuntamento d = null;
		try {
			d = new Appuntamento("Roberto Bianchi", luogoA, "17-12-2019", "18:12", 35);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		agenda.inserisciAppuntamento(d);
		assertEquals("Il numero di appuntamenti è 6",6,agenda.getAppuntamenti().size());
		assertEquals("Cerco l'appuntamento con persona=Bianchi, "
				+ "mi aspetto che il risultato contenga 2 appuntamenti",2,agenda.cercaAppuntamento("Bianchi").size());
		Appuntamento e = null;
		try {
			e = new Appuntamento("Maria Bianchi", luogoC, "17-06-2019", "15:12", 35);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		agenda.inserisciAppuntamento(e);
		assertEquals("Il numero di appuntamenti è 7",7,agenda.getAppuntamenti().size());
		assertEquals("Cerco l'appuntamento con persona=Maria Bianchi, "
				+ "mi aspetto di trovare due appuntamenti con persona=Maria Bianchi",2,agenda.cercaAppuntamento("Maria Bianchi").size());
		Luogo luogoD = null;
		try {
			luogoD = new Luogo("Roma, Via Condotti, 15");
		} catch (LuogoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		Appuntamento f = null;
		try {
			f = new Appuntamento("Maria Bianchi", luogoD, "25-06-2019", "21:45", 300);
		} catch (AppuntamentoBadFormatException e1) {
			System.out.println(e1.getMessage());
		}
		agenda.inserisciAppuntamento(f);
		assertEquals("Il numero di appuntamenti è 8",8,agenda.getAppuntamenti().size());
		assertEquals("Cerco l'appuntamento con persona=Maria Bianchi, "
				+ "mi aspetto di trovare 3 appuntamenti con persona=Maria Bianchi",3,agenda.cercaAppuntamento("Maria Bianchi").size());
		appuntamenti.remove(c);
		assertEquals("Il numero di appuntamenti "
				+ "dopo la cancellazione di un appuntamento è 7",7,agenda.getAppuntamenti().size());
		assertEquals("Cerco l'appuntamento con persona=Maria Bianchi, "
				+ "mi aspetto di trovare 2 appuntamenti con Maria Bianchi perché il primo è stato rimosso",2,agenda.cercaAppuntamento("Maria Bianchi").size());
		assertEquals("Cerco l'appuntamento con persona=Giuseppe Verdi, "
				+ "mi aspetto di trovare 1 solo appuntamento con nome Giuseppe Verdi",1,agenda.cercaAppuntamento("Giuseppe Verdi").size());
		assertEquals("Cerco l'appuntamento con persona=Marco Rossi, "
				+ "mi aspetto di trovare 1 solo appuntamento con nome Marco Rossi",3,agenda.cercaAppuntamento("Marco Rossi").size());
	}

	
	@Test
	public void testModificaAppuntamento() {
		
		testInserimentoAppuntamenti();
		
		assertEquals("Modifico la persona in Giulia e il luogo di a in Firenze, "
				+ "mi aspetto valore di ritorno = true",true,agenda.modificaAppuntamento("12-05-2019", "23:44", null,null, "Giulia", "Firenze",null));
		assertEquals("Modifico tutto di a tranne il nome, "
				+ "mi aspetto valore di ritorno = true",true,agenda.modificaAppuntamento("12-05-2019", "23:44", "24-06-2019", "12:20", null, "Torino, piazza Centrale","30"));
		assertEquals("I primi due parametri non corrispondono a nessun appuntamento esistente nell'agenda, "
				+ "mi aspetto valore di ritorno = false",false,agenda.modificaAppuntamento("01-12-2023", "00:50", "24-10-2018", "12:20", null, "Alessandria","30"));
		assertEquals("Modifico l'intero appuntamento che ha persona = Giuseppe Verdi, ma c'è già un appuntamento con stessa data e orario quindi"
				+ "mi aspetto valore di ritorno = false",false,agenda.modificaAppuntamento("02-06-2018", "23:30", "12-05-2019", "00:41", "Paolo Rossi", "Torino, piazza Centrale 88","0"));
		assertEquals("Modifico l'intero appuntamento che ha persona = Giuseppe Verdi, ma c'è una sovrapposizione di data e orario per via della durata quindi"
				+ "mi aspetto valore di ritorno = false",false,agenda.modificaAppuntamento("02-06-2018", "23:30", "12-05-2019", "00:30", "Paolo Rossi", "Torino, piazza Centrale 88","20"));
		assertEquals("Provo a modificare un appuntamento, ma dato che passo null per data e orario da cercare nell'agenda"
				+ "mi aspetto valore di ritorno = false",false,agenda.modificaAppuntamento(null, null, "12-05-2019", "00:30", "Paolo Rossi", "Torino, piazza Centrale 88","20"));
	}
	
	@Test
	public void testRimuoviAppuntamento() {
		testInserimentoAppuntamenti();
		assertEquals("Dopo gli inserimenti l'agenda ha 3 Marco Rossi, "
				+ "1 Giovanni Neri e 1 Maria Bianchi -> 5 elementi", 5, agenda.getAppuntamenti().size());
		Appuntamento d = null;
		try {
			d = new Appuntamento("Marco Rossi",luogoA, "05-10-2019","23:44", 24);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Rimuovo l'appuntamento d "
				+ "(che ha gli stessi valori dei campi di un appuntamento in agenda)", true, agenda.rimuoviAppuntamento(d));
		assertEquals("Dopo la rimozione dell'appuntamento precedente l'agenda ha 4 appuntamenti", 4, agenda.getAppuntamenti().size());
		assertEquals("Provo di nuovo a rimuovere d, ma ottengo false perché l'ho già rimosso", false, agenda.rimuoviAppuntamento(d));
		assertEquals("Dopo la rimozione fallita l'agenda ha ancora 4 appuntamenti", 4, agenda.getAppuntamenti().size());
		assertEquals("Rimuovo l'appuntamento b, mi aspetto che abbia successo", true, agenda.rimuoviAppuntamento(b));
		assertEquals("Dopo la rimozione dell'appuntamento precedente l'agenda ha 3 appuntamenti", 3, agenda.getAppuntamenti().size());
		assertEquals("Rimuovo l'appuntamento c, mi aspetto che abbia successo", true, agenda.rimuoviAppuntamento(c));
		assertEquals("Dopo la rimozione dell'appuntamento precedente l'agenda ha 2 appuntamenti", 2, agenda.getAppuntamenti().size());
		assertEquals("Rimuovo l'appuntamento a, mi aspetto che abbia successo", true, agenda.rimuoviAppuntamento(a));
		assertEquals("Dopo la rimozione dell'appuntamento precedente l'agenda ha 1 appuntamenti", 1, agenda.getAppuntamenti().size());
	}

}
