package agenda.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.LocalTime;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import agenda.*;
import agenda.exception.AppuntamentoBadFormatException;
import agenda.exception.BadFormatException;
import agenda.exception.LuogoBadFormatException;

public class TestAppuntamento {

	private Appuntamento a=null,b=null,c=null;
	private Luogo luogoA=null, luogoB=null, luogoC=null;
	
	
	@Before
	public void init() {
		try {
			luogoA = new Luogo("Novi Ligure, Via Verdi 24");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoA!=null);
		try {
			luogoB = new Luogo("Alessandria, Via Roma 88");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoB!=null);
		try {
			luogoC = new Luogo("Torino, Via Inganni 50");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(luogoC!=null);
		try {
			a = new Appuntamento("Marco Rossi",luogoA, "12-05-2019","23:44", 24);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
		try {
			b = new Appuntamento("Giuseppe Verdi", luogoB, "12-05-2019", "23:30", 15);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
		try {
			c = new Appuntamento("Maria Bianchi", luogoC, "12-05-2019", "22:10", 79);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(a!=null);
	}
	
	@After
	public void reset() {
		luogoA = null;
		assertTrue(luogoA==null);
		luogoB = null;
		assertTrue(luogoB==null);
		luogoC = null;
		assertTrue(luogoC==null);
		a = null;
		assertTrue(a==null);
		b = null;
		assertTrue(b==null);
		c = null;
		assertTrue(c==null);
	}
	
	
	@Test
	public void testImpostaOrario() {
		assertEquals("Vecchio orario dell'appuntamento a", LocalTime.parse("23:44"),a.getOrario());
		try {
			a.setOrario("08:35");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuovo orario dell'appuntamento a", LocalTime.parse("08:35"),a.getOrario());
		
		assertEquals("Vecchio orario dell'appuntamento b", LocalTime.parse("23:30"),b.getOrario());
		try {
			b.setOrario("14:45");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuovo orario dell'appuntamento b", LocalTime.parse("14:45"),b.getOrario());
		
		assertEquals("Vecchio orario dell'appuntamento c", LocalTime.parse("22:10"),c.getOrario());
		try {
			c.setOrario("22:58");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuovo orario dell'appuntamento c", LocalTime.parse("22:58"),c.getOrario());
		
	}
	
	@Test
	public void testImpostaData() {
		try {
		a.setData("02-05-2019");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Vecchia data dell'appuntamento a", LocalDate.parse("2019-05-02"),a.getData());
		try {
			a.setData("25-06-2019");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuova data dell'appuntamento a", LocalDate.parse("2019-06-25"),a.getData());
		
		try {
			b.setData("10-08-2018");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Vecchia data dell'appuntamento b", LocalDate.parse("2018-08-10"),b.getData());
		try {
			b.setData("7-02-2019");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuova data dell'appuntamento b", LocalDate.parse("2019-02-07"),b.getData());
		
		try {
			c.setData("23-11-2020");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Vecchia data dell'appuntamento c", LocalDate.parse("2020-11-23"),c.getData());
		try {
			c.setData("14-12-2020");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Nuova data dell'appuntamento c", LocalDate.parse("2020-12-14"),c.getData());
	}
	
	@Test
	public void testSovrapposizione()
	{	
		assertEquals("Controllo sovrapposizione di b su c: ", false,b.sovrapposto(c));
		c.setDurata(90);
		assertEquals("Controllo sovrapposizione di b su c: ", true,b.sovrapposto(c));
		assertEquals("Controllo sovrapposizione di c su b: ", true,c.sovrapposto(b));
		assertEquals("Controllo sovrapposizione di a su c :", false, a.sovrapposto(c));
		assertEquals("Controllo sovrapposizione di c su a :", false, c.sovrapposto(a));
		c.setDurata(110);
		assertEquals("Controllo sovrapposizione di a su c :", true, a.sovrapposto(c));
		assertEquals("Controllo sovrapposizione di c su a :", true, c.sovrapposto(a));
		try {
			a.setOrario("23:59");
		} catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertEquals("Controllo sovrapposizione di a su b :", false, a.sovrapposto(b));
		assertEquals("Controllo sovrapposizione di a su c :", true, a.sovrapposto(c));
		c.setDurata(15);
		assertEquals("Controllo sovrapposizione di c su b :", false, c.sovrapposto(b));
		assertEquals("Controllo sovrapposizione di c su a :", false, c.sovrapposto(a));
		a.setDurata(50);
		assertEquals("Controllo sovrapposizione di a su b :", false, a.sovrapposto(b));
		assertEquals("Controllo sovrapposizione di a su c :", false, a.sovrapposto(c));
		try {
			a.setData("13-05-2019");
		}catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		try {
			a.setOrario("00:30");
		}catch (BadFormatException e) {
			System.out.println(e.getMessage());
		}
		b.setDurata(100);
		assertEquals("Controllo sovrapposizione di b su a: ", true,b.sovrapposto(a));
		assertEquals("Controllo sovrapposizione di b su c: ", false,b.sovrapposto(c));
		b.setDurata(45);
		assertEquals("Controllo sovrapposizione di b su a: ", false,b.sovrapposto(a));
	}
	
	@Test
	public void testCompareTo() {
		assertEquals("Mi aspetto che il valore di ritorno sia 1",1,a.compareTo(b));
		assertEquals("Mi aspetto che il valore di ritorno sia -1",-1,b.compareTo(a));
		Appuntamento d = null;
		try {
			d = new Appuntamento("Maria Bianchi", luogoC, "12-05-2019", "22:10", 79);
		} catch (AppuntamentoBadFormatException e) {
			System.out.println(e.getMessage());
		} // i dati di d sono copiati da quelli di c
		assertEquals("Mi aspetto che il valore di ritorno sia 0",0,c.compareTo(d));
		assertEquals("Mi aspetto che l'equals di c e d restituisca true",true,d.equals(c));
		assertEquals("Mi aspetto che il valore di ritorno sia -1",-1,c.compareTo(a));
		assertEquals("Mi aspetto che il valore di ritorno sia 0",0,d.compareTo(c));
		assertEquals("Mi aspetto che il valore di ritorno sia -1",-1,c.compareTo(b));
		assertEquals("Mi aspetto che il valore di ritorno sia 1",1,a.compareTo(c));
		assertEquals("Mi aspetto che il valore di ritorno sia 1",1,b.compareTo(c));
		assertEquals("Mi aspetto che il valore di ritorno sia 1",1,a.compareTo(d));
		assertEquals("Mi aspetto che il valore di ritorno sia 1",1,b.compareTo(d));
		assertEquals("Mi aspetto che il valore di ritorno sia -1",-1,d.compareTo(a));
		assertEquals("Mi aspetto che il valore di ritorno sia -1",-1,d.compareTo(b));

	}

}
