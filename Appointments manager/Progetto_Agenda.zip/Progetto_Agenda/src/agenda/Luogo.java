package agenda;

import java.util.regex.PatternSyntaxException;

import agenda.exception.LuogoBadFormatException;

/**
 * La classe Luogo è usata per creare un luogo</br>
 * Ogni luogo ha una città e un indirizzo
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 */
public class Luogo implements Comparable<Luogo>{
	
	/*Variabili d' istanza*/
	private String citta;
	private String indirizzo;
	
	
	/*Costruttori*/
	/**
	 * Crea un oggetto di tipo Luogo</br>
	 * con i campi impostati per default a "Nessuna città" e "Nessun indirizzo"
	 */
	public Luogo()
	{
		this("Nessuna città","Nessun indirizzo");
	}
	
	/**
	 * Crea un oggetto di tipo Luogo
	 * parsificando la stringa <b>luogo</b> tramite il metodo splitLuogo(String luogo):
	 * <ul>
	 * <li>se non è presente il carattere "," l'intera stringa è assengata a città</li>
	 * <li>altrimenti ciò che si trova dopo la prima occorrenza del carattere "," 
	 * è considerato indirizzo</li>
	 * </ul>
	 * @param luogo stringa che rappresenta un luogo
	 * @throws LuogoBadFormatException denota un errore nel formato dell'input
	 */
	public Luogo(String luogo) throws LuogoBadFormatException
	{
		String[] arr = null;
		try{
			arr = splitLuogo(luogo);
			this.citta = arr[0];
			this.indirizzo = arr[1];
		}catch (LuogoBadFormatException e) {
			throw new LuogoBadFormatException();
		}
		
	}
	
	/**
	 * Crea un oggetto di tipo Luogo 
	 * inizializzandone i campi con i rispettivi valori forniti in input
	 * @param citta da impostare al luogo che si vuole creare
	 * @param indirizzo da impostare al luogo che si vuole creare
	 */
	public Luogo(String citta, String indirizzo)
	{
		this.citta = (citta == null ? "Nessuna città" : citta);
		this.indirizzo = (indirizzo == null ? "Nessun indirizzo" : indirizzo);
	}
	
	
	/* Metodo privato di servizio*/
	/**
	 * Metodo di servizio che divide la stringa fornita in input in sottostringhe
	 * che restituisce tramite array String[]</br>
	 * Il metodo parsifica la stringa <b>luogo</b>:
	 * <ul>
	 * <li>se non è presente il carattere "," l'intera stringa è assengata a città</br>
	 * e l'indirizzo è impostato a "Nessun indirizzo"</li>
	 * <li>altrimenti ciò che si trova dopo la prima occorrenza del carattere "," 
	 * è considerato indirizzo, mentre la parte che lo precede rappresenta la città</li>
	 * </ul>
	 * @param luogo stringa da suddividere in sottostringhe
	 * @return <b>String[]</b> che rappresenta l'insieme delle sottostringhe
	 * @throws LuogoBadFormatException denota un errore nel formato dell'input
	 */
	private String[] splitLuogo(String luogo) throws LuogoBadFormatException
	{
		String[] arrayString = new String[2];
		if(luogo==null);
		if(luogo.contains(",")) {
			String [] arr = new String[2];
			try {
				arr = luogo.split(",",2);
			}
			catch(PatternSyntaxException e) {
				throw new LuogoBadFormatException();
			}
			arrayString[0] = arr[0];
			if(Character.isSpaceChar(arr[1].charAt(0))) {
				arr[1] = arr[1].substring(1);
			}
			arrayString[1] = arr[1];
		}
		else {
			arrayString[0] = luogo;
			arrayString[1] = "Nessun indirizzo";
		}
		return arrayString;
	}
	
	
	/*Metodi*/
	/**
	 * Imposta la città con il valore fornito in input
	 * @param citta da impostare
	 */
	public void setCitta(String citta)
	{
		this.citta = (citta == null ? "Nessuna città" : citta);
	}
	
	/**
	 * Imposta l'indirizzo con il valore fornito in input
	 * @param indirizzo da impostare
	 */
	public void setIndirizzo(String indirizzo)
	{
		this.indirizzo = (indirizzo == null ? "Nessun indirizzo" : indirizzo);
	}
	
	/**
	 * Restituisce la città
	 * @return <b>città</b> appartenente a un luogo
	 */
	public String getCitta() { return citta; }
	
	/**
	 * Restituisce l'indirizzo
	 * @return <b>indirizzo</b> di una specifica città appartenente a un luogo
	 */
	public String getIndirizzo() { return indirizzo; }
	
	/**
	 * Ridefinisce il compareTo per adattarlo alla classe Luogo
	 * @return <ul>
	 * <li><b>1</b> se città o indirizzo (in caso di città uguali) del luogo su cui 
	 * è richiamato il metodo è lessicograficamente successiva/o 
	 * a città o indirizzo (in caso di città uguali) del luogo passato come parametro</li>
	 * <li><b>0</b> se i luoghi sono uguali</li>
	 * <li><b>-1</b> se città o indirizzo (in caso di città uguali) del luogo su cui 
	 * è richiamato il metodo è lessicograficamente precedente  
	 * a città o indirizzo (in caso di città uguali) del luogo passato come parametro</li>
	 * </ul>
	 */
	@Override
	public int compareTo(Luogo luogo) {
		
		if(this.citta.compareToIgnoreCase(luogo.getCitta())>0) return 1;
		if(this.citta.compareToIgnoreCase(luogo.getCitta())<0) return -1;
		if(this.indirizzo.compareToIgnoreCase(luogo.getIndirizzo())>0) return 1;
		if(this.indirizzo.compareToIgnoreCase(luogo.getIndirizzo())<0) return -1;
		return 0;
	}
	
	/**
	 * Ridefinisce il toString() di Object adattandolo alla classe Luogo</br>
	 * Restituisce una stringa che rappresenta l'oggetto Luogo
	 * @return la stringa che rappresenta l'oggetto Luogo
	 */
	@Override
	public String toString() {
		return citta + ", " + indirizzo;
	}
	
	/**
	 * Ridefinisce il metodo equals() di Object adattandolo alla classe Luogo
	 * @param obj oggetto con cui confrontare un'istanza di Luogo
	 * @return <b>true</b> se obj è uguale alla corrente istanza di Luogo, <b>false</b> altrimenti
	 
	 */
	@Override
	public boolean equals(Object obj)
	{
		if(obj==null || obj.getClass()!=this.getClass()) return false;
		Luogo luogo = (Luogo) obj;
		return citta.equals(luogo.getCitta()) && indirizzo.equals(luogo.getIndirizzo());
	}
	

}
