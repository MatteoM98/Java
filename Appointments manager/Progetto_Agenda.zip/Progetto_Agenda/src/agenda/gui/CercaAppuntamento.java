package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import agenda.Agenda;
import agenda.Appuntamento;

/**
 * Permette di cercare un certo appuntamento nell' <b>agenda</b>.</br>
 * La ricerca può essere effettuata:
 * <ul>
 * <li> per nome </li>
 * <li> per data e ora </li>
 * </ul>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class CercaAppuntamento extends JFrame implements WindowListener, ActionListener, ItemListener  {
	
	public static final int LARGHEZZA = 750;
	public static final int ALTEZZA = 500;
	public static final int RIGHE = 200;
	public static final int CARATTERI_PER_RIGA = 200;
	
	//variabili
	private Agenda agenda;
	
	private JButton cerca;
	
	private JTextField testoNome;
	
	private JRadioButton radioNome;
	private JRadioButton radioDataOra;
	
	private ButtonGroup radioGroup;
	
	private JPanel dataOraPanel;
	private JPanel testiPanel;
	private JPanel radioPanel;
	private JPanel upperPanel;
	private JPanel pannelloComboData;
	private JPanel pannelloComboOra;
	
	private JTextArea testo;
	
	private JScrollPane scroll;
	
	private JComboBox <String>  comboGiorni = new JComboBox <String> (CostantiAgenda.GIORNI);
	private JComboBox <String>  comboMesi   = new JComboBox <String> (CostantiAgenda.MESI);
	private JComboBox <String>  comboAnni   = new JComboBox <String> (CostantiAgenda.ANNI);
	private JComboBox <String>  comboOra    = new JComboBox <String> (CostantiAgenda.ORE);
	private JComboBox <String>  comboMinuti = new JComboBox <String> (CostantiAgenda.MINUTI);
	
	/**
	 * Genera un frame che offre all' utente vari campi
	 * (come pulsanti,text area e combo box) per ricercare un' appuntamento e stamparlo.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe <b>Agenda</b>
	 * per poterne ricercare correttemente i contenuti.
	 * 
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public CercaAppuntamento(Agenda agenda)
	{
		this.agenda = agenda;
		
				//vari metodi set
				setSize(LARGHEZZA,ALTEZZA);
				setTitle("Cerca");
				setResizable(true);

				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

				//vari listener
				addWindowListener(this);
						
						
				//pannello principale
				Container pannelloPrincipale = getContentPane();
				pannelloPrincipale.setLayout(new BorderLayout());
				pannelloPrincipale.setBackground(Color.BLACK);
				
				
				//varie label
				JLabel cercaAppuntamento = new JLabel("Come vuoi effettuare la ricerca?");
				cercaAppuntamento.setFont(new Font("Arial",Font.PLAIN,14));
				cercaAppuntamento.setHorizontalAlignment(SwingConstants.CENTER);
				cercaAppuntamento.setForeground(Color.WHITE);
				//pulsante di inserimento
				cerca = new JButton("Cerca");
				cerca.setActionCommand("search");
				cerca.addActionListener(this);
				getRootPane().setDefaultButton(cerca);
				
				//vari text field
				Font f = new Font("Serif",Font.ITALIC,12);
				
				testoNome = new JTextField("Scrivi qua il nome");
				testoNome.setBackground(Color.GRAY);
				testoNome.setEditable(false);
				testoNome.setFont(f);
				testoNome.addMouseListener(new SvuotaTesto(testoNome,"Scrivi qua il nome"));
				
				//vari radio button 
				radioNome = new JRadioButton("Nome persona");
				radioNome.addItemListener(this);
				radioNome.setBackground(Color.BLACK);
				radioNome.setForeground(Color.WHITE);
				
				radioDataOra = new JRadioButton("Data e Ora");
				radioDataOra.addItemListener(this);
				radioDataOra.setBackground(Color.BLACK);
				radioDataOra.setForeground(Color.WHITE);
				
				radioGroup = new ButtonGroup();
				radioGroup.add(radioNome);
				radioGroup.add(radioDataOra);
				
				//disabilitazione delle combo box di modifica
				comboGiorni.setEnabled(false);
				comboMesi.setEnabled(false);
				comboAnni.setEnabled(false);
				
				comboOra.setEnabled(false);
				comboMinuti.setEnabled(false);
				
				//vari pannelli
				pannelloComboData = new JPanel();
				pannelloComboData.setLayout(new FlowLayout());
				pannelloComboData.add(comboGiorni);
				pannelloComboData.add(comboMesi);
				pannelloComboData.add(comboAnni);
				pannelloComboData.setBackground(Color.GRAY);

				pannelloComboOra = new JPanel();
				pannelloComboOra.setLayout(new FlowLayout());
				pannelloComboOra.add(comboOra);
				pannelloComboOra.add(comboMinuti);
				pannelloComboOra.setBackground(Color.GRAY);

				dataOraPanel = new JPanel();
				dataOraPanel.setLayout(new GridLayout(2,1));
				dataOraPanel.add(pannelloComboData);
				dataOraPanel.add(pannelloComboOra);
				dataOraPanel.setBackground(Color.BLACK);

				testiPanel = new JPanel();
				testiPanel.setLayout(new GridLayout(1,2));
				testiPanel.add(testoNome);
				testiPanel.add(dataOraPanel);
				testiPanel.setBackground(Color.BLACK);
				
				radioPanel = new JPanel();
				radioPanel.setLayout(new GridLayout(1,2));
				radioPanel.add(radioNome);
				radioPanel.add(radioDataOra);
				radioPanel.setBackground(Color.BLACK);

				upperPanel = new JPanel();
				upperPanel.setLayout(new GridLayout(3,1));
				upperPanel.add(cercaAppuntamento);
				upperPanel.add(radioPanel);
				upperPanel.add(testiPanel);
				upperPanel.setBackground(Color.BLACK);

				//creazione text area
				testo = new JTextArea(RIGHE, CARATTERI_PER_RIGA);
				testo.setBackground(Color.LIGHT_GRAY);
				testo.setEditable(false);
				
				//creazione scrollbar
				scroll = new JScrollPane(testo);
			    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			    
				
				//aggiunta dei pannelli nel frame
				pannelloPrincipale.add(upperPanel,BorderLayout.NORTH);
				pannelloPrincipale.add(cerca,BorderLayout.SOUTH);
				pannelloPrincipale.add(scroll);
				
				
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		
	}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		
	}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento dei
	 * campi di input (in caso contrario notifica l'
	 * utente) ed esegue una ricerca dell' appuntamento
	 * (notifica l'utente nel caso non sia presente).</br>
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		String comando = arg0.getActionCommand();
		
		if(comando.equals("search")) {
			
			if(agenda!=null) {
				//ricavo parametri
				String data = comboGiorni.getSelectedItem().toString()+"-"+comboMesi.getSelectedItem().toString()+"-"+comboAnni.getSelectedItem().toString();
				String ora =  comboOra.getSelectedItem().toString()+":"+comboMinuti.getSelectedItem().toString();
				String nome = (testoNome.getText().equals("Scrivi qua il nome") || testoNome.getText().equals("")) ? null : testoNome.getText();
				//verifico quale funzione richiamare
				if(radioNome.isSelected()) {
					ArrayList<Appuntamento> appuntamenti = new ArrayList<>();
					appuntamenti = agenda.cercaAppuntamento(nome);
					if(appuntamenti==null){
						JOptionPane.showMessageDialog(null,"Ricerca fallita!"
								+ "\nVerificare la correttezza dei dati inseriti (1)\n"
								+ "Controllare l'effettiva presenza del nome che si desidera cercare (2).","Error",JOptionPane.ERROR_MESSAGE);
					}else{
						String app = "";
						for(Appuntamento a: appuntamenti)
							app += a.toString()+"\n";
						testo.setText(app);
					}
				}else if (radioDataOra.isSelected()) {
					Appuntamento appuntamento = agenda.cercaAppuntamento(data, ora);
					if(appuntamento==null) {
						JOptionPane.showMessageDialog(null,"Ricerca fallita!"
								+ "\nVerificare la correttezza dei dati inseriti (1)\n"
								+ "Controllare l'effettiva presenza dell' appuntamento che si desidera cercare (2).","Error",JOptionPane.ERROR_MESSAGE);
					}else testo.setText(appuntamento.toString());
					
				}
				
			}
		}
		
	}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo item (come la selezione di una checkbox o radio button)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica l' eventuale selezionamento o non 
	 * dei vari radio button e in base a questa informazione
	 * esegue particolari azioni come rendere editabile o meno 
	 * la text area.</br>
	 * @param arg0 determina l'evento di tipo item
	 */
	@Override
	public void itemStateChanged(ItemEvent arg0) {
		
		if(radioNome.isSelected()) {
			testoNome.setBackground(Color.WHITE);
			testoNome.setEditable(true);
		}else if (!radioNome.isSelected())
		{
			testoNome.setBackground(Color.GRAY);
			testoNome.setEditable(false);
		}
		
		if(radioDataOra.isSelected()) {
			comboGiorni.setEnabled(true);
			comboMesi.setEnabled(true);
			comboAnni.setEnabled(true);
			comboOra.setEnabled(true);
			comboMinuti.setEnabled(true);
		}else if (!radioDataOra.isSelected())
		{
			comboGiorni.setEnabled(false);
			comboMesi.setEnabled(false);
			comboAnni.setEnabled(false);
			comboOra.setEnabled(false);
			comboMinuti.setEnabled(false);
		}
		
	}

}
