package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;



import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Permette di accedere all' <b>agenda</b> vera e propria.</br>
 * Per poter catturare particolari eventi è stata
 * implementata l' interfaccia <b>WindowListener</b>.
 * 
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class FinestraDiAccesso extends JFrame implements WindowListener{
	
	//variabili
	public static final int LARGHEZZA = 450;
	public static final int ALTEZZA = 120;
	private JPasswordField password;
	private JTextField utente;
	private JButton conferma;
	private JPanel pannelloPassword;
	private JPanel pannelloConferma;
	private JTextField testo;
	
	/**
	 * Genera un frame che offre all' utente la 
	 * possibilità di loggare all' interno dell'
	 * agenda.</br>
	 * */
	public FinestraDiAccesso()
	{
		//richiamo costruttore della superclasse
		super();
		
		
		//vari set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Accesso");
		setResizable(false);

		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new BorderLayout());
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		
		//label	
		JLabel user = new JLabel("UserName");
		user.setToolTipText("Inserire utente nello spazio qui affianco");
		user.setHorizontalAlignment(SwingConstants.CENTER);
		user.setForeground(Color.WHITE);
		
		JLabel pwd = new JLabel("Password");
		pwd.setToolTipText("Inserire password nello spazio qui affianco");
		pwd.setHorizontalAlignment(SwingConstants.CENTER);
		pwd.setForeground(Color.WHITE);
		
		// utente field
		utente = new JTextField();
		
		
		//password field
		password = new JPasswordField();
		
		//pulsanti
		conferma = new JButton("Conferma");
		conferma.addActionListener( new ButtonHandler());
		getRootPane().setDefaultButton(conferma);
		conferma.setBackground(Color.BLACK);
		conferma.setForeground(Color.WHITE);
		
		//testo
		testo = new JTextField(20);
		testo.setEditable(false);
		testo.setFont(new Font("Serif",Font.BOLD + Font.ITALIC,14));
		testo.setBackground(Color.BLACK);
		testo.setForeground(Color.WHITE);


		//pannelli
		pannelloPassword = new JPanel();
		pannelloPassword.setLayout(new GridLayout(2,2));
		pannelloPassword.add(user);
		pannelloPassword.add(utente);
		pannelloPassword.add(pwd);
		pannelloPassword.add(password);
		pannelloPassword.setBackground(Color.BLACK);
		
		pannelloConferma = new JPanel();
		pannelloConferma.setLayout(new GridLayout(1,2));
		pannelloConferma.add(conferma);
		pannelloConferma.add(testo);
		pannelloConferma.setBackground(Color.BLACK);
		
		//inserimento pannello
		pannelloPrincipale.add(pannelloConferma,BorderLayout.SOUTH);
		pannelloPrincipale.add(pannelloPassword,BorderLayout.CENTER);
		//lister
		addWindowListener(this);
		
	}

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e termina
	 * il programma.
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		System.exit(0);
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}
	
	
	/* CLASSI INTERNE */
	/**
	 * Cattura un evento di tipo azione generato
	 * e verifica la password per poter accedere
	 * all' agenda.</br>
	 * @author Matteo Magrì
	 * @author Gabriele Ferrari
	 *
	 */
	public class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String comando = e.getActionCommand();
			
			if(comando.equals("Conferma")) {
				
				String pass = new String(password.getPassword());
				String uName = utente.getText();
				if (pass.equals("agenda2019")) {
					
						testo.setText("Password corretta!");
						FinestraPrincipale fp = new FinestraPrincipale("AgendaDemo",uName);
						fp.setVisible(true);
						dispose();
						
				} else testo.setText("Password non corretta!");
			
				
	    	} else
			{
				System.out.println("Errore nei pulsanti");
				System.exit(0);
			}
			
		}

	}

}
