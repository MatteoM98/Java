package agenda.exception;

/**
 * Eccezione sollevata quando viene inserito un formato sbagliato in input che riguarda un appuntamento;</br>
 * estende la classe BadFormatException
 * @see BadFormatException
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 */
@SuppressWarnings("serial")
public class AppuntamentoBadFormatException extends BadFormatException {
	
	/**
	 * Crea un oggetto di tipo AppuntamentoBadFormatException richiamando il costruttore 
	 * della classe BadFormatException
	 */
	public AppuntamentoBadFormatException() {
		
		super("Formato Appuntamento errato");
	}
	
	/**
	 * Crea un oggetto di tipo AppuntamentoBadFormatException richiamando il costruttore 
	 * della classe BadFormatException con il parametro messaggio
	 * @param messaggio stringa che descrive l'anomalia 
	 */
	public AppuntamentoBadFormatException(String messaggio) {
		
		super(messaggio);
	}
	

}
