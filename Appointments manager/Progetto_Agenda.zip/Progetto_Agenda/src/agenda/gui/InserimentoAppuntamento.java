package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import agenda.Agenda;
import agenda.Appuntamento;
import agenda.Luogo;
import agenda.exception.AppuntamentoBadFormatException;
import agenda.exception.LuogoBadFormatException;

/**
 * Permette di inserire un nuovo appuntamento nell' <b>agenda</b>.</br>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class InserimentoAppuntamento extends JFrame implements WindowListener, ActionListener, ItemListener {
	
	public static final int LARGHEZZA = 350;
	public static final int ALTEZZA = 250;
	
	//variabili
	private Agenda agenda;
	private JButton inserimento;
	private JTextField testoNome;
	private JTextField testoLuogo;
	private JTextField testoDurata;
	
	private JPanel pannelloNome;
	private JPanel pannelloLuogo;
	private JPanel pannelloData;
	private JPanel pannelloOra;
	private JPanel pannelloDurata;
	private JPanel pannelloComponenti;
	private JPanel pannelloComboData;
	private JPanel pannelloComboOra;
	
	private JComboBox <String>  comboGiorni = new JComboBox <String> (CostantiAgenda.GIORNI);
	private JComboBox <String>  comboMesi   = new JComboBox <String> (CostantiAgenda.MESI);
	private JComboBox <String>  comboAnni   = new JComboBox <String> (CostantiAgenda.ANNI);
	private JComboBox <String>  comboOra    = new JComboBox <String> (CostantiAgenda.ORE);
	private JComboBox <String>  comboMinuti = new JComboBox <String> (CostantiAgenda.MINUTI);
		
	
	/**
	 * Genera un frame che offre all' utente vari campi
	 * (come pulsanti e text area) per caricare  un' appuntamento.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe. <b>Agenda</b>
	 *
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public InserimentoAppuntamento(Agenda agenda)
	{
		this.agenda = agenda;
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Inserimento");
		setResizable(false);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		//vari listener
		addWindowListener(this);
				
				
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		setLayout(new BorderLayout());
		pannelloPrincipale.setBackground(Color.BLACK);
		
		//varie label
		JLabel persona = new JLabel("Nome:");
		persona.setToolTipText("Inserisci il nome della persona con cui hai l'appuntamento");
		persona.setHorizontalAlignment(SwingConstants.CENTER);
		persona.setForeground(Color.WHITE);
		
		JLabel luogo = new JLabel("Luogo:");
		luogo.setToolTipText("Inserisci il luogo dell' incontro");
		luogo.setHorizontalAlignment(SwingConstants.CENTER);
		luogo.setForeground(Color.WHITE);
		
		JLabel data = new JLabel("* Data:  ");
		data.setToolTipText("Inserisci la data dell' appuntamento");
		data.setHorizontalAlignment(SwingConstants.CENTER);
		data.setForeground(Color.WHITE);
		
		JLabel ora = new JLabel("* Ora: HH:MM");
		ora.setToolTipText("Inserisci l' ora dell' appuntamento");
		ora.setHorizontalAlignment(SwingConstants.CENTER);
		ora.setForeground(Color.WHITE);
		
		JLabel durata = new JLabel("Durata:");
		durata.setToolTipText("Inserisci la durata dell' appuntamento");
		durata.setHorizontalAlignment(SwingConstants.CENTER);
		durata.setForeground(Color.WHITE);
		
		//pulsante di inserimento
		inserimento = new JButton("Inserisci");
		inserimento.addActionListener(this);
		getRootPane().setDefaultButton(inserimento);
		
		//vari text field
		Font f = new Font("Serif",Font.ITALIC,12);
		testoNome = new JTextField("Scrivi qua il nome");
		testoNome.setFont(f);
		testoNome.addMouseListener(new SvuotaTesto(testoNome,"Scrivi qua il nome"));
		
		testoLuogo = new JTextField("Citta'[,indirizzo civico]");
		testoLuogo.setFont(f);
		testoLuogo.addMouseListener(new SvuotaTesto(testoLuogo,"Citta'[,indirizzo civico]"));
		
		testoDurata = new JTextField("Scrivi la durata in minuti (numero intero)");
		testoDurata.setFont(f);
		testoDurata.addMouseListener(new SvuotaTesto(testoDurata,"Scrivi la durata in minuti (numero intero)"));
		
		//vari pannelli
		pannelloNome = new JPanel();
		pannelloNome.setLayout(new  FlowLayout());
		pannelloNome.add(persona);
		pannelloNome.add(testoNome);
		pannelloNome.setBackground(Color.BLACK);
		
		pannelloLuogo = new JPanel();
		pannelloLuogo.setLayout(new  FlowLayout());
		pannelloLuogo.add(luogo);
		pannelloLuogo.add(testoLuogo);
		pannelloLuogo.setBackground(Color.BLACK);

		pannelloDurata = new JPanel();
		pannelloDurata.setLayout(new  FlowLayout());
		pannelloDurata.add(durata);
		pannelloDurata.add(testoDurata);
		pannelloDurata.setBackground(Color.BLACK);

		pannelloComboData = new JPanel();
		pannelloComboData.setLayout(new FlowLayout());
		pannelloComboData.add(comboGiorni);
		pannelloComboData.add(comboMesi);
		pannelloComboData.add(comboAnni);
		pannelloComboData.setBackground(Color.BLACK);

		pannelloComboOra = new JPanel();
		pannelloComboOra.setLayout(new FlowLayout());
		pannelloComboOra.add(comboOra);
		pannelloComboOra.add(comboMinuti);
		pannelloComboOra.setBackground(Color.BLACK);

		pannelloData = new JPanel();
		pannelloData.setLayout(new  FlowLayout());
		pannelloData.add(data);
		pannelloData.add(pannelloComboData);
		pannelloData.setBackground(Color.BLACK);

		pannelloOra = new JPanel();
		pannelloOra.setLayout(new  FlowLayout());
		pannelloOra.add(ora);
		pannelloOra.add(pannelloComboOra);
		pannelloOra.setBackground(Color.BLACK);

		
		pannelloComponenti = new JPanel();
		pannelloComponenti.setLayout(new GridLayout(5,1));
		pannelloComponenti.add(pannelloNome);
		pannelloComponenti.add(pannelloLuogo);
		pannelloComponenti.add(pannelloData);
		pannelloComponenti.add(pannelloOra);
		pannelloComponenti.add(pannelloDurata);
		pannelloComponenti.setBackground(Color.BLACK);

		pannelloPrincipale.add(inserimento,BorderLayout.SOUTH);
		pannelloPrincipale.add(pannelloComponenti,BorderLayout.CENTER);
		
		
	}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento dei
	 * campi di input (in caso contrario notifica l'
	 * utente) ed esegue l'inserimento dell' appuntamento 
	 * (notifica l' utente in caso di errore). </br>
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getActionCommand().equals("Inserisci")) {
			if(agenda!=null) {
				String nome = (testoNome.getText().equals("Scrivi qua il nome") || testoNome.getText().equals("")) ? null : testoNome.getText();
				String l = (testoLuogo.getText().equals("Citta'[,indirizzo civico]") || testoLuogo.getText().equals("")) ? "Nessuna città,Nessun indirizzo" : testoLuogo.getText();
				Luogo luogo = null;
				try {
					luogo = new Luogo(l);
				} catch (LuogoBadFormatException e) {
					System.out.println(e.getMessage());
				}
				String data = comboGiorni.getSelectedItem().toString()+"-"+comboMesi.getSelectedItem().toString()+"-"+comboAnni.getSelectedItem().toString();
				String ora =  comboOra.getSelectedItem().toString()+":"+comboMinuti.getSelectedItem().toString();
				long durata = (testoDurata.getText().equals("Scrivi la durata in minuti (numero intero)") || testoDurata.getText().equals("")) ? Long.parseLong("0") : Long.parseLong(testoDurata.getText().trim());
				if(data==null || ora==null) {
					JOptionPane.showMessageDialog(null, "Attenzione!\nTutti i campi marcati con '*' sono obbligatori.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
				else {
					Appuntamento app = null;
					try {
						app = new Appuntamento(nome,luogo,data,ora,durata);
					} catch (AppuntamentoBadFormatException e) {
						
						JOptionPane.showMessageDialog(null, "Attenzione!\nControllare la correttezza del formato dei vari campi", "Warning", JOptionPane.WARNING_MESSAGE);
					}
					if(agenda.inserisciAppuntamento(app)) {
						JOptionPane.showMessageDialog(null, "Inserimento di:\n\nNome: "+app.getPersona()+"\n"
							+ "Luogo: "+app.getLuogo()+"\nData: "+app.getData()+"\nOra: "+app.getOrario()+"\n"
									+ "Durata: "+app.getDurata().toMinutes()+" min\n\nha avuto successo.", "Messaggio di conferma", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						JOptionPane.showMessageDialog(null, "Inserimento fallito!\n"
								+ "\nControllare se l'appuntamento e' gia' esistente"
								+ "\noppure si sovrappone ad altri appuntamenti.", "Messaggio di conferma", JOptionPane.ERROR_MESSAGE);
						
					}
				}
				
			}
			
			
		}
		
	}
		

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		
	}

}
