package agenda.gui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextField;

/**
 * Classe che permette di "pulire" la text area
 * quando viene cliccata con il mouse
 * @author Matteo Magrì
 * @author Gabriele Ferrari 
 */
public class SvuotaTesto extends MouseAdapter {
	private JTextField testo;
	private String text;
	
	/**
	 * Crea un' istanza della classe <b>SvuotaTestp</b>
	 * per gestire la text area.
	 * @param testo area di testo
	 * @param text stringa di testo da confrontare
	 */
	public SvuotaTesto(JTextField testo,String text) {
		 this.testo = testo;
		 this.text = text;
	}
	
	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo mouse (come il click del tasto sinistro)
	 * e svolgere particolari azioni.</br>
	 * Il metodo "pulisce" la text area se il
	 * suo contenuto è uguale a <b>text</b>.
	 * @param e determina l' evento di tipo mouse 
	 */
	@Override
    public void mouseClicked(MouseEvent e) {
		if(testo.getText().equals(text))
			testo.setText("");
    }

}
