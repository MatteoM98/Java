package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import agenda.Agenda;
import agenda.Appuntamento;


/**
 * Permette di eliminare un certo appuntamento dall' <b>agenda</b>.</br>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class CancellaAppuntamento extends JFrame implements WindowListener, ActionListener{
	
	public static final int LARGHEZZA = 400;
	public static final int ALTEZZA = 180;
	
	//variabili
	private Agenda agenda;
	private JButton cancella;
	
	private JPanel pannelloComboData;
	private JPanel pannelloComboOra;
	private JPanel pannelloComponenti;
	
	private JComboBox <String>  comboGiorni = new JComboBox <String> (CostantiAgenda.GIORNI);
	private JComboBox <String>  comboMesi   = new JComboBox <String> (CostantiAgenda.MESI);
	private JComboBox <String>  comboAnni   = new JComboBox <String> (CostantiAgenda.ANNI);
	private JComboBox <String>  comboOra    = new JComboBox <String> (CostantiAgenda.ORE);
	private JComboBox <String>  comboMinuti = new JComboBox <String> (CostantiAgenda.MINUTI);
		
	
	/**
	 * Genera un frame che offre all' utente vari campi
	 * (come pulsanti e combo box) per ricercare un' appuntamento ed eliminarlo.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe <b>Agenda</b>
	 * per poterne rendere visibili le modifiche anche alle altre classi.
	 * 
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public CancellaAppuntamento(Agenda agenda)
	{
		this.agenda = agenda;
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Rimozione");
		setResizable(false);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		//vari listener
		addWindowListener(this);
				
				
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new BorderLayout());
		pannelloPrincipale.setBackground(Color.BLACK);
		
		//varie label
		JLabel data = new JLabel("* Data: ");
		data.setToolTipText("Inserisci la data dell' appuntamento");
		data.setHorizontalAlignment(SwingConstants.CENTER);
		data.setForeground(Color.WHITE);
		
		JLabel ora = new JLabel("* Ora: ");
		ora.setToolTipText("Inserisci l' ora dell' appuntamento");
		ora.setHorizontalAlignment(SwingConstants.CENTER);		
		ora.setForeground(Color.WHITE);

		JLabel etichettaCancella = new JLabel("Cerca l'appuntamento da cancellare (per data e ora)");
		etichettaCancella.setToolTipText("Inserisci data e ora dell'appuntamento da rimuovere");
		etichettaCancella.setForeground(Color.WHITE);

		
		//pulsante cancella
		cancella = new JButton("Cancella");
		cancella.addActionListener(this);
		getRootPane().setDefaultButton(cancella);
		
		
		//vari pannelli
		pannelloComboData = new JPanel();
		pannelloComboData.setLayout(new FlowLayout());
		pannelloComboData.add(data);
		pannelloComboData.add(comboGiorni);
		pannelloComboData.add(comboMesi);
		pannelloComboData.add(comboAnni);
		pannelloComboData.setBackground(Color.BLACK);

		pannelloComboOra = new JPanel();
		pannelloComboOra.setLayout(new FlowLayout());
		pannelloComboOra.add(ora);
		pannelloComboOra.add(comboOra);
		pannelloComboOra.add(comboMinuti);
		pannelloComboOra.setBackground(Color.BLACK);

		pannelloComponenti = new JPanel();
		pannelloComponenti.setLayout(new GridLayout(2,1));
		pannelloComponenti.add(pannelloComboData);
		pannelloComponenti.add(pannelloComboOra);
		pannelloComponenti.setBackground(Color.BLACK);

		pannelloPrincipale.add(cancella,BorderLayout.SOUTH);
		pannelloPrincipale.add(etichettaCancella,BorderLayout.NORTH);
		pannelloPrincipale.add(pannelloComponenti,BorderLayout.CENTER);
		
		
	}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento dei
	 * campi di input (in caso contrario notifica l'
	 * utente), esegue una ricerca dell' appuntamento
	 * (notifica l'utente nel caso non sia presente) e
	 * lo elimina
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getActionCommand().equals("Cancella")) {
			if(agenda!=null) {
				String data = comboGiorni.getSelectedItem().toString()+"-"+comboMesi.getSelectedItem().toString()+"-"+comboAnni.getSelectedItem().toString();
				String ora =  comboOra.getSelectedItem().toString()+":"+comboMinuti.getSelectedItem().toString();
				
				if(data==null || ora==null) {
					JOptionPane.showMessageDialog(null, "Attenzione!!!\nTutti i campi marcati con '*' sono obbligatori.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
				else {
					Appuntamento app = agenda.cercaAppuntamento(data, ora);
					
					if(agenda.rimuoviAppuntamento(app)) {
						JOptionPane.showMessageDialog(null, "Appuntamento:\n\nNome: "+app.getPersona()+"\n"
							+ "Luogo: "+app.getLuogo()+"\nData: "+app.getData()+"\nOra: "+app.getOrario()+"\n"
									+ "Durata: "+app.getDurata().toMinutes()+" min\n\nrimosso con successo.", "Messaggio di conferma", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						JOptionPane.showMessageDialog(null,"Rimozione fallita!"
								+ "\nVerificare la correttezza dei dati inseriti (1)\n"
								+ "Controllare l'effettiva presenza dell'appuntamento che si desidera cancellare (2).","Error",JOptionPane.ERROR_MESSAGE);
						
					}
				}
				
			}
			
			
		}
		
	}

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

}
