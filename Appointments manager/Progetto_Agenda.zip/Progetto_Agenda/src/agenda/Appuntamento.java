package agenda;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.regex.PatternSyntaxException;

import agenda.exception.AppuntamentoBadFormatException;
import agenda.exception.BadFormatException;

/**
 * La classe Appuntamento è usata per creare un appuntamento</br>
 * <ul>
 * Ogni oggetto di tipo Appuntamento ha i seguenti campi:
 * <li><b>data</b> di tipo LocalDate, rappresenta la data dell'appuntamento</li>
 * <li><b>orario</b> di tipo LocalTime, rappresenta l'ora dell'appuntamento</li> 
 * <li><b>durata</b> di tipo Duration, rappresenta la durata dell'appuntamento</li>
 * <li><b>persona</b> di tipo String, rappresenta la persona con cui si ha l'appuntamento</li>
 * <li><b>luogo</b> di tipo Luogo, rappresenta il luogo dell'appuntamento</li>
 * </ul>
 * @see Luogo
 * @see Agenda
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 */
public class Appuntamento implements Comparable<Appuntamento> {
	
	
	private LocalDate data;
	private LocalTime orario;
	private Duration durata;
	private String persona;
	private Luogo luogo;
	

	/**
	 * Crea un oggetto di tipo Appuntamento
	 * @param persona con cui si ha l'appuntamento
	 * @param luogo dell'appuntamento
	 * @param data dell'appuntamento
	 * @param orario dell'appuntamento
	 * @param durata dell'appuntamento
	 * @throws AppuntamentoBadFormatException denota un errore nel formato dell'input
	 * @see BadFormatException
	 */
	public Appuntamento(String persona, Luogo luogo, String data, String orario, long durata) throws AppuntamentoBadFormatException
	{
		if(durata<0) this.durata = Duration.ofMinutes(0);
		
		try {
			this.data = convertiData(data);
		}catch(BadFormatException e) {throw new AppuntamentoBadFormatException(e.getMessage());}
		
		try {
			this.orario = LocalTime.parse(orario);
		}catch(DateTimeParseException e) {throw new AppuntamentoBadFormatException("Formato ora errato"); }
		
		this.durata = Duration.ofMinutes(durata);
		this.persona = (persona == null ? "None" : persona);
		this.luogo = (luogo == null ? new Luogo() : luogo);
		
	}
	
	/**
	 * Crea un oggetto di tipo Appuntamento
	 * @param data
	 * @param orario
	 * @param persona
	 * @throws AppuntamentoBadFormatException denota un errore nel formato dell'input
	 * @see BadFormatException
	 */
	public Appuntamento(String data,String orario,String persona) throws AppuntamentoBadFormatException
	{
		this(persona,null,data,orario,0);
	}
	
	
	
	/**
	 * Imposta l'orario dell'appuntamento con il valore fornito in input
	 * @param orario da impostare
	 * @throws BadFormatException denota un errore nel formato dell'input
	 */
	public void setOrario(String orario) throws BadFormatException
	{	
		try {
			this.orario = LocalTime.parse(orario);
		} catch (DateTimeParseException e) {
			throw new BadFormatException("Formato data errato");
		}
	}
	
	/**
	 * Imposta la data dell'appuntamento con il valore fornito in input
	 * @param data da impostare
	 * @throws BadFormatException denota un errore nel formato dell'input
	 */
	public void setData(String data) throws BadFormatException
	{
		try {
			this.data = convertiData(data);
		}catch (BadFormatException e) {
			throw new BadFormatException("Formato data errato");
		}

	}
	
	/**
	 * Imposta la persona, con cui si ha l'appuntamento, con il valore fornito in input
	 * @param persona da impostare
	 */
	public void setPersona(String persona)
	{
		this.persona = (persona == null ? "None" : persona);
	}
	
	/**
	 * Imposta il luogo dell'appuntamento con il valore fornito in input
	 * @param luogo da impostare
	 */
	public void setLuogo(Luogo luogo)
	{
		this.luogo = (luogo == null ? new Luogo() : luogo);
	}
	
	/**
	 * Imposta la durata dell'appuntamento con il valore fornito in input
	 * @param durata da impostare
	 */
	public void setDurata(long durata)
	{
		this.durata = (durata < 0 ? Duration.ofMinutes(0) : Duration.ofMinutes(durata));
	}
	
	/**
	 * Restituisce l'orario dell'appuntamento
	 * @return <b>orario</b> dell'appuntamento
	 */
	public LocalTime getOrario() { return orario; }
	
	/**
	 * Restituisce la data dell'appuntamento
	 * @return <b>data</b> dell'appuntamento
	 */
	public LocalDate getData() { return data; }
	
	/**
	 * Restituisce la persona con cui si ha l'appuntamento
	 * @return <b>persona</b> con cui si ha l'appuntamento
	 */
	public String getPersona() { return persona; }
	
	/**
	 * Restituisce il luogo dell'appuntamento
	 * @return <b>luogo</b> dell'appuntamento
	 */
	public Luogo getLuogo() { return luogo; }
	
	/**
	 * Restituisce la durata dell'appuntamento
	 * @return <b>durata</b> dell'appuntamento
	 */
	public Duration getDurata() { return durata; }
	
	
	/**
	 * Controlla se due appuntamenti sono sovrapposti</br>
	 * Dati due appuntamenti app1 e app2</br>
	 * <ul>
	 * <li>se app1 finisce prima che app2 inizi,</br>
	 * oppure se app1 inizia dopo che app2 finisca,</br>
	 * app1 non è sovrapposto ad app2</li>
	 * <li>altrimenti è sovrapposto</li>
	 * </ul>
	 * @param nuovo appuntamento da controllare se si sovrappone ad altro appuntamento
	 * @return <b>true</b> se è sovrapposto, <b>false</b> altrimenti
	 */
	public boolean sovrapposto(Appuntamento nuovo)
	{
		boolean uguale = true;
		LocalDateTime dataNuovoInizio = nuovo.getData().atTime(nuovo.getOrario()); //trovo data e ora dell' appuntamento app
		LocalDateTime dataQuestoInizio = this.getData().atTime(this.getOrario()); //trovo data e ora dell' istanza

		LocalDateTime dataNuovoFine = dataNuovoInizio.plusMinutes(nuovo.getDurata().toMinutes()); //trovo data e ora di fine dell' appuntamento app
		LocalDateTime dataQuestoFine = dataQuestoInizio.plusMinutes(this.getDurata().toMinutes()); //trovo data e ora di fine dell' istanza
		
		if((dataNuovoInizio.isAfter(dataQuestoFine) || dataNuovoFine.isBefore(dataQuestoInizio))) uguale = false;
		return uguale;
	}
	
	/*Metodi di Servizio*/
	/**
	 * Converte la data in input di tipo String con formato gg-mm-aaaa</br>
	 * in una data di tipo LocalDate con formato aaaa-mm-gg
	 * @param data stringa che rappresenta la data in formato gg-mm-aaaa
	 * @return <b>data convertita</b> in LocalDate con formato aaaa-mm-gg
	 * @throws BadFormatException denota un errore nel formato dell'input
	 */
	static LocalDate convertiData (String data) throws BadFormatException
	{
		String[] array = new String[3];
		try {
		array = data.split("[- ./]");
		} catch (PatternSyntaxException e) {throw new BadFormatException("Formato data errato"); }
		array[0] = (array[0].length()==1 ? "0"+array[0] : array[0]);
		array[1] = (array[1].length()==1 ? "0"+array[1] : array[1]);
		array[2] = (array[2].length()==2 ? "20"+array[2] : array[2]);
		String giorno = array[0];
		String mese = array[1];
		String anno = array[2];
		LocalDate nuovaData = null;
		try {
			nuovaData =  LocalDate.parse(anno+"-"+mese+"-"+giorno);
		} catch (DateTimeParseException e) {
			throw new BadFormatException("Formato data errato");
		}
		return nuovaData;
	}
	
	/**
	 * Converte la data in input di tipo LocalDate con formato aaaa-mm-gg</br>
	 * in una data di tipo String con formato gg-mm-aaaa
	 * @param data LocalDate che rappresenta la data in formato aaaa-mm-gg
	 * @return <b>data convertita</b> in String con formato gg-mm-aaaa
	 * @throws BadFormatException denota un errore nel formato dell'input
	 */
	static String convertiDataNelFormatoItaliano (LocalDate data) throws BadFormatException
	{
		String date = data.toString();
		String[] array = new String[3];
		try {
			array = date.split("[- ./]");
		} catch (PatternSyntaxException e) {
			throw new BadFormatException("Formato data errato");
		}
		String anno = array[0];
		String mese = array[1];
		String giorno = array[2];
		String dataIta =  giorno+"-"+mese+"-"+anno;
		return dataIta;
	}
	
	
	/*Metodi sovrascritti*/
	/**
	 * Ridefinisce il compareTo per adattarlo alla classe Appuntamento
	 * @return <ul>
	 * <li><b>1</b> se data e ora dell'appuntamento su cui è richiamato il metodo sono successive
	 * a data e ora dell'appuntamento passato come parametro</li>
	 * <li><b>0</b> se gli appuntamenti sono uguali</li>
	 * <li><b>-1</b> se data e ora dell'appuntamento su cui è richiamato il metodo sono precedenti
	 * a data e ora dell'appuntamento passato come parametro</li>
	 * </ul>
	 */
	@Override
	public int compareTo(Appuntamento o)
	{
		LocalDateTime questoInizio = this.getData().atTime(this.getOrario());
		LocalDateTime altroInizio = o.getData().atTime(o.getOrario());
		
		if(questoInizio.isEqual(altroInizio) && durata.equals(o.getDurata()) && luogo.equals(o.getLuogo()) && persona.equals(o.getPersona())) return 0;
		if(questoInizio.isAfter(altroInizio)) return 1;
		return -1;
	}
	
	/**
	 * Ridefinisce il toString() di Object adattandolo alla classe Appuntamento</br>
	 * Restituisce una stringa che rappresenta l'oggetto Appuntamento
	 * @return la stringa che rappresenta l'oggetto Appuntamento
	 */
	@Override
	public String toString()
	{
		String date = null;
		try
		{
		  date = convertiDataNelFormatoItaliano(data);
		}catch (BadFormatException e) { return null;}
		
		return persona + "	" + luogo + "	" + date + "	" + orario + "	" + durata.toMinutes();
	}
	
	/**
	 * Ridefinisce il metodo equals() di Object adattandolo alla classe Appuntamento
	 * @param obj oggetto con cui confrontare un'istanza di Appuntamento
	 * @return <b>true</b> se obj è uguale alla corrente istanza di Appuntamento, <b>false</b> altrimenti
	 */
	@Override
	public boolean equals(Object obj)
	{
		if(obj==null || obj.getClass()!=this.getClass()) return false;
		Appuntamento appuntamento = (Appuntamento) obj;
		return orario.equals(appuntamento.getOrario())    &&
			   data.equals(appuntamento.getData()) 	      &&
			   luogo.equals(appuntamento.getLuogo())      &&
			   persona.equals(appuntamento.getPersona())  &&
			   durata.equals(appuntamento.getDurata());
	}
	

}
