package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.TreeSet;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import agenda.Agenda;
import agenda.Appuntamento;


/**
 * Permette di salvare gli appuntamenti dell' <b>agenda</b>
 * caricandoli su un file fornendo il percorso assoluto
 * di dove si voglia salvare quest' ultimo.</br>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class SalvaAgendaSuFile extends JFrame implements WindowListener, ActionListener{
	
	public static final int LARGHEZZA = 550;
	public static final int ALTEZZA = 250;
	
	//variabili
	private Agenda agenda;
	private JButton caricamento;
	private JTextField testoPercorso;
	
	private JPanel pannelloStringa;
	private JPanel pannelloPercorso;
	private JPanel pannelloComponenti;
	
	/**
	 * Genera un frame che offre all' utente la possibilità
	 * di salvare gli appuntamenti su un file.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe. <b>Agenda</b>
	 *
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public SalvaAgendaSuFile(Agenda agenda)
	{
		this.agenda = agenda;
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Scelta file di appuntamenti");
		setResizable(false);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));
		
		//vari listener
		addWindowListener(this);
				
				
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new BorderLayout());
		pannelloPrincipale.setBackground(Color.BLACK);
		
		//varie label
		JLabel stringa = new JLabel("Inserire il percorso (assoluto) della directory e il nome del file");
		stringa.setToolTipText("Inserisci il percorso");
		stringa.setHorizontalAlignment(SwingConstants.CENTER);
		stringa.setForeground(Color.WHITE);
		
		
		//pulsante di caricamento
		caricamento = new JButton("Salva");
		caricamento.addActionListener(this);
		caricamento.setHorizontalAlignment(SwingConstants.CENTER);
		getRootPane().setDefaultButton(caricamento);
		
		//vari text field
		Font f = new Font("Serif",Font.ITALIC,12);
		testoPercorso = new JTextField("Inserisci il percorso",30);
		testoPercorso.setFont(f);
		testoPercorso.setHorizontalAlignment(SwingConstants.LEFT);
		testoPercorso.addMouseListener(new SvuotaTesto(testoPercorso,"Inserisci il percorso"));
		
		//vari pannelli
		pannelloPercorso = new JPanel();
		pannelloPercorso.setLayout(new FlowLayout());
		pannelloPercorso.add(testoPercorso);
		pannelloPercorso.add(caricamento);
		pannelloPercorso.setBackground(Color.BLACK);

		pannelloStringa = new JPanel();
		pannelloStringa.setLayout(new GridLayout(1,1));
		pannelloStringa.add(stringa);
		pannelloStringa.setBackground(Color.BLACK);

		
		pannelloComponenti = new JPanel();
		pannelloComponenti.setLayout(new GridLayout(2,1));
		pannelloComponenti.add(pannelloStringa);
		pannelloComponenti.add(pannelloPercorso);
		pannelloComponenti.setBackground(Color.BLACK);

		pannelloPrincipale.add(pannelloComponenti,BorderLayout.CENTER);
		
		
	}
	
	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento del
	 * campo di input (in caso contrario notifica l'
	 * utente) ed esegue l'inserimento degli appuntamenti 
	 * (notifica l' utente in caso di errore) sul file. </br>
	 * 
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(arg0.getActionCommand().equals("Salva")) {
			if(agenda!=null) {
				String nomeFile = (testoPercorso.getText().equals("Inserire il percorso della directory") || testoPercorso.getText().equals("")) ? null : testoPercorso.getText();
				if(nomeFile==null)
				{
					JOptionPane.showMessageDialog(null, "Inserire un percorso valido\n","Warning",JOptionPane.WARNING_MESSAGE);
				}
				
				PrintWriter output = null;
				boolean successo = false;
				try {
					output = new PrintWriter(nomeFile);
				}catch (FileNotFoundException e) {
					JOptionPane.showMessageDialog(null,"Impossibile trovare la directory inserita!!","Error",JOptionPane.ERROR_MESSAGE);
					dispose();
				}
				
				successo = scriviAgendasuFile(agenda,output);
				if(successo==false)
				{
					JOptionPane.showMessageDialog(null, "Errore!!!\nImpossibile leggere il file.","Error",JOptionPane.ERROR_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, "L'agenda e' stata salvata con successo.","Messaggio di conferma",JOptionPane.INFORMATION_MESSAGE);
				}
				output.close();
			}else JOptionPane.showMessageDialog(null, "Nessuna agenda da salvare","Warning",JOptionPane.WARNING_MESSAGE);
			
			
		}
		
	}

	/**
	 * Metodo che permette di scrivere
	 * un singolo appuntamento su file.</br> 
	 * 
	 * @param app determina l' appuntamento da scrivere su file
	 * @param file determina il file sul quale scrivere l' appuntamento
	 * @return <b>true</b> in caso di successo <b>false</b> altrimenti
	 */
	private static boolean scriviAppuntamentoSuFile (Appuntamento app, PrintWriter file)
	{
		if(file==null || app==null) return false;
		file.println(app);
		return true;
	}
	
	/**
	 * Metodo che permette di scrivere
	 * un' agenda su file.</br> 
	 * 
	 * @param agenda determina l' agenda da scrivere su file
	 * @param file determina il file sul quale scrivere l' appuntamento
	 * @return <b>true</b> in caso di successo <b>false</b> altrimenti
	 */
	private static boolean scriviAgendasuFile (Agenda agenda, PrintWriter file)
	{
		if(agenda==null || file==null) return false;
		TreeSet <Appuntamento> app = agenda.getAppuntamenti();
		for(Appuntamento a : app)
			if(!scriviAppuntamentoSuFile(a,file)) return false;
		return true;
	}
	
	
	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

}
