package agenda.gui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import agenda.Agenda;
import agenda.Appuntamento;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.*;
import java.util.TreeSet;

/**
 * Finestra principale dell' <b>agenda</b>  la quale
 * permette di scegliere le varie azioni da intraprendere. 
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari 
 *
 */
@SuppressWarnings("serial")
public class FinestraPrincipale extends JFrame implements ActionListener,WindowListener {

	public static final int LARGHEZZA = 700;
	public static final int ALTEZZA = 550;
	
	private Agenda agenda;
	private String nomeUtente;
	private JButton pulsanteCrea;
	private JButton pulsanteInserimento;
	private JButton pulsanteCancellazione;
	private JButton pulsanteModifica;
	private JButton pulsanteCerca;
	private JButton pulsanteCarica;
	private JButton pulsanteVisualizzazione;
	private JButton pulsanteSalva;
	
	private JPanel pannelloTitolo;
	private JPanel pannelloCrea;
	private JPanel pannelloInserimento;
	private JPanel pannelloCancellazione;
	private JPanel pannelloModifica;
	private JPanel pannelloCerca;
	private JPanel pannelloCarica;
	private JPanel pannelloVisualizzazione;
	private JPanel pannelloSalva;
	
	/**
	 * Genera un frame che offre all' utente la 
	 * possibilità di svolgere particolari azioni, come:
	 * <ul>
		 * <li> creare un' agenda </li>
		 * <li> inserire un' appuntamento </li>
		 * <li> cancellare un' appuntamento </li>
		 * <li> modificare un' appuntamento </li>
		 * <li> cercare un' appuntamento </li>
		 * <li> caricare degli appuntamenti da file </li>
		 * <li> visualizzare l' agenda </li>
		 * <li> salvare gli appuntamenti su file </li>
	 * </ul>
	 * @param nomeFinestra definisce il titolo della finestra
	 * @param colore definisce il colore in background
	 * */
	public FinestraPrincipale(String nomeFinestra, String nomeUtente)
	{
		super();
		
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle(nomeFinestra);
		this.nomeUtente = nomeUtente;

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		//vari listener
		addWindowListener(this);
		
		
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new GridLayout(9,1));
		pannelloPrincipale.setBackground(Color.BLACK);
		
		
		//varie label
		JLabel etichettaTitolo = new JLabel("Agenda di "+nomeUtente);
		etichettaTitolo.setFont(new Font("Libration Serif",Font.BOLD,18));
		etichettaTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		etichettaTitolo.setForeground(Color.WHITE);
		
		JLabel crea = new JLabel("Crea agenda");
		crea.setToolTipText("Clicca sul pulsante per creare una nuova agenda");
		crea.setHorizontalAlignment(SwingConstants.CENTER);
		crea.setForeground(Color.WHITE);

		
		JLabel inserimento = new JLabel("Inserisci appuntamento");
		inserimento.setToolTipText("Clicca sul pulsante per creare e aggiungere un nuovo appuntamento");
		inserimento.setHorizontalAlignment(SwingConstants.CENTER);
		inserimento.setForeground(Color.WHITE);
		
		JLabel elimina = new JLabel("Elimina appuntamento");
		elimina.setToolTipText("Clicca sul pulsante per eliminare un appuntamento");
		elimina.setHorizontalAlignment(SwingConstants.CENTER);
		elimina.setForeground(Color.WHITE);
		
		JLabel modifica = new JLabel("Modifica appuntamento");
		modifica.setToolTipText("Clicca sul pulsante per modificare un appuntamento");
		modifica.setHorizontalAlignment(SwingConstants.CENTER);
		modifica.setForeground(Color.WHITE);
		
		JLabel cerca = new JLabel("Cerca appuntamento");
		cerca.setToolTipText("Clicca sul pulsante per cercare un certo appuntamento");
		cerca.setHorizontalAlignment(SwingConstants.CENTER);
		cerca.setForeground(Color.WHITE);
		
		JLabel carica = new JLabel("Carica appuntamenti da file");
		carica.setToolTipText("Clicca sul pulsante per leggere una lista di appuntamenti da file");
		carica.setHorizontalAlignment(SwingConstants.CENTER);
		carica.setForeground(Color.WHITE);
		
		JLabel salva = new JLabel("Salva appuntamenti su file");
		salva.setToolTipText("Clicca sul pulsante personalizzare la tua agenda");
		salva.setHorizontalAlignment(SwingConstants.CENTER);
		salva.setForeground(Color.WHITE);
		
		JLabel visualizza = new JLabel("Visualizza agenda");
		visualizza.setToolTipText("Clicca sul pulsante visualizzare tutti i tuoi appuntamenti");
		visualizza.setHorizontalAlignment(SwingConstants.CENTER);
		visualizza.setForeground(Color.WHITE);
		
		
		
		//vari pulsanti
		pulsanteCrea = new JButton("Crea");
		pulsanteCrea.setActionCommand("create");
		pulsanteCrea.addActionListener(this);
		
		pulsanteInserimento = new JButton("Inserisci");
		pulsanteInserimento.setActionCommand("insert");
		pulsanteInserimento.addActionListener(this);
		
		pulsanteCancellazione = new JButton("Cancella");
		pulsanteCancellazione.setActionCommand("delete");
		pulsanteCancellazione.addActionListener(this);
		
		pulsanteModifica = new JButton("Modifica");
		pulsanteModifica.setActionCommand("modify");
		pulsanteModifica.addActionListener(this);
		
		pulsanteCerca = new JButton("Cerca");
		pulsanteCerca.setActionCommand("search");
		pulsanteCerca.addActionListener(this);
		
	    pulsanteCarica = new JButton("Carica");
		pulsanteCarica.setActionCommand("upload");
		pulsanteCarica.addActionListener(this);
		
		pulsanteSalva = new JButton("Salva");
		pulsanteSalva.setActionCommand("save");
		pulsanteSalva.addActionListener(this);
		
		pulsanteVisualizzazione = new JButton("Visualizza");
		pulsanteVisualizzazione.setActionCommand("print");
		pulsanteVisualizzazione.addActionListener(this);
		
		
		//creazione dei pannelli
		pannelloTitolo = new JPanel();
		pannelloTitolo.setLayout(new GridLayout(1,1));
		pannelloTitolo.add(etichettaTitolo,"Center");
		pannelloTitolo.setBackground(Color.BLACK);
		
		
		pannelloCrea = new JPanel();
		pannelloCrea.setLayout(new GridLayout(1,2));
		pannelloCrea.add(crea);
		pannelloCrea.add(pulsanteCrea);
		pannelloCrea.setBackground(Color.BLACK);

		
		pannelloInserimento = new JPanel();
		pannelloInserimento.setLayout(new GridLayout(1,2));
		pannelloInserimento.add(inserimento);
		pannelloInserimento.add(pulsanteInserimento);
		pannelloInserimento.setBackground(Color.BLACK);

		
		pannelloCancellazione = new JPanel();
		pannelloCancellazione.setLayout(new GridLayout(1,2));
		pannelloCancellazione.add(elimina);
		pannelloCancellazione.add(pulsanteCancellazione);
		pannelloCancellazione.setBackground(Color.BLACK);

		
		pannelloModifica = new JPanel();
		pannelloModifica.setLayout(new GridLayout(1,2));
		pannelloModifica.add(modifica);
		pannelloModifica.add(pulsanteModifica);
		pannelloModifica.setBackground(Color.BLACK);

		
		pannelloCerca = new JPanel();
		pannelloCerca.setLayout(new GridLayout(1,2));
		pannelloCerca.add(cerca);
		pannelloCerca.add(pulsanteCerca);
		pannelloCerca.setBackground(Color.BLACK);

		
		pannelloCarica = new JPanel();
		pannelloCarica.setLayout(new GridLayout(1,2));
		pannelloCarica.add(carica);
		pannelloCarica.add(pulsanteCarica);
		pannelloCarica.setBackground(Color.BLACK);


		pannelloSalva = new JPanel();
		pannelloSalva.setLayout(new GridLayout(1,2));
		pannelloSalva.add(salva);
		pannelloSalva.add(pulsanteSalva);
		pannelloSalva.setBackground(Color.BLACK);

		pannelloVisualizzazione = new JPanel();
		pannelloVisualizzazione.setLayout(new GridLayout(1,2));
		pannelloVisualizzazione.add(visualizza);
		pannelloVisualizzazione.add(pulsanteVisualizzazione);
		pannelloVisualizzazione.setBackground(Color.BLACK);

		
		//aggiunta pannelli al frame
		pannelloPrincipale.add(pannelloTitolo);
		pannelloPrincipale.add(pannelloCrea);
		pannelloPrincipale.add(pannelloInserimento);
		pannelloPrincipale.add(pannelloCancellazione);
		pannelloPrincipale.add(pannelloModifica);
		pannelloPrincipale.add(pannelloCerca);
		pannelloPrincipale.add(pannelloCarica);
		pannelloPrincipale.add(pannelloSalva);
		pannelloPrincipale.add(pannelloVisualizzazione);
		
		
	}
	
	public String getNomeUtente() {
		return this.nomeUtente;
	}
	
	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il comando lanciato e genera
	 * l' opportuna finestra.
	 * @param e determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed (ActionEvent e)
	{
		String comando = e.getActionCommand();
		
		if(comando.equals("create")) {
			TreeSet<Appuntamento> appuntamenti = null;
			agenda = new Agenda("Agenda",appuntamenti);
			JOptionPane.showMessageDialog(null, "Agenda creata correttamente", "Messaggio di conferma", JOptionPane.INFORMATION_MESSAGE);
		}
		else if(comando.equals("insert")) {
			if(agenda!=null) {
				InserimentoAppuntamento ia = new InserimentoAppuntamento(agenda);
				ia.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di inserire un appuntamento\nsi deve creare l'agenda con l'apposito pulsante.", "Warning", JOptionPane.WARNING_MESSAGE);

			}
			
		}
		else if(comando.equals("delete")) {
			if(agenda!=null) {
				CancellaAppuntamento ca = new CancellaAppuntamento(agenda);
				ca.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di cancellare un appuntamento\nsi deve creare l'agenda con l'apposito pulsante\ne aver inserito almeno un'appuntamento.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(comando.equals("modify")) {
			if(agenda!=null) {
				ModificaAppuntamento ma = new ModificaAppuntamento(agenda);
				ma.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di modificare un appuntamento\nsi deve creare l'agenda con l'apposito pulsante\ne aver inserito almeno un'appuntamento.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(comando.equals("search")) {
			if(agenda!=null) {
				CercaAppuntamento ca = new CercaAppuntamento(agenda);
				ca.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di cercare un appuntamento\nsi deve creare l'agenda con l'apposito pulsante\ne aver inserito almeno un'appuntamento.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(comando.equals("upload")) {
			if(agenda!=null) {
				InserimentoAppuntamentoDaFile iadf = new InserimentoAppuntamentoDaFile(agenda);
				iadf.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di caricare appuntamenti da file\nsi deve creare l'agenda con l'apposito pulsante.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(comando.equals("print")) {
			if(agenda!=null) {
				VisualizzaAgenda va = new VisualizzaAgenda(agenda);
				va.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di visualizzare l'agenda\nla si deve creare con l'apposito pulsante\ne occorre inserire almeno un'appuntamento", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(comando.equals("save")) {
			if(agenda!=null) {
				SalvaAgendaSuFile sasf = new SalvaAgendaSuFile(agenda);
				sasf.setVisible(true);
			}
			else {
				JOptionPane.showMessageDialog(null, "Attenzione!!!\nPrima di salvare l'agenda\nla si deve creare con l'apposito pulsante\ne occorre inserire almeno un'appuntamento", "Warning", JOptionPane.WARNING_MESSAGE);
			}
	
		}

		
			
	}

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e termina
	 * il programma.
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		System.exit(0);
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

	

	
	
}
