package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.PatternSyntaxException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import agenda.Agenda;
import agenda.Appuntamento;
import agenda.Luogo;
import agenda.exception.BadFormatException;

/**
 * Permette di inserire nuovi appuntamento nell' <b>agenda</b>
 * caricandoli da file fornerndo il percorso assoluto
 * di quest' ultimo.</br>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class InserimentoAppuntamentoDaFile extends JFrame implements WindowListener, ActionListener{
	
	public static final int LARGHEZZA = 550;
	public static final int ALTEZZA = 250;
	
	//variabili
	private Agenda agenda;
	private JButton caricamento;
	private JTextField testoPercorso;
	
	private JPanel pannelloStringa;
	private JPanel pannelloPercorso;
	private JPanel pannelloComponenti;
	
	/**
	 * Genera un frame che offre all' utente la possibilità
	 * di caricare gli appuntamenti da file.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe. <b>Agenda</b>
	 *
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public InserimentoAppuntamentoDaFile(Agenda agenda)
	{
		this.agenda = agenda;
		
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Scelta file di appuntamenti");
		setResizable(false);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		//vari listener
		addWindowListener(this);
				
				
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new BorderLayout());
		pannelloPrincipale.setBackground(Color.BLACK);
		
		//varie label
		JLabel stringa = new JLabel("Inserire il percorso (assoluto) del file da caricare");
		stringa.setToolTipText("Inserisci il percorso del file da caricare");
		stringa.setHorizontalAlignment(SwingConstants.CENTER);
		stringa.setForeground(Color.WHITE);
		
		
		//pulsante di caricamento
		caricamento = new JButton("Carica");
		caricamento.addActionListener(this);
		caricamento.setHorizontalAlignment(SwingConstants.CENTER);
		getRootPane().setDefaultButton(caricamento);
		
		//vari text field
		Font f = new Font("Serif",Font.ITALIC,12);
		testoPercorso = new JTextField("Inserire il percorso del file",30);
		testoPercorso.setFont(f);
		testoPercorso.setHorizontalAlignment(SwingConstants.LEFT);
		testoPercorso.addMouseListener(new SvuotaTesto(testoPercorso,"Inserire il percorso del file"));
		
		
		//vari pannelli
		pannelloPercorso = new JPanel();
		pannelloPercorso.setLayout(new FlowLayout());
		pannelloPercorso.add(testoPercorso);
		pannelloPercorso.add(caricamento);
		pannelloPercorso.setBackground(Color.BLACK);

		pannelloStringa = new JPanel();
		pannelloStringa.setLayout(new GridLayout(1,1));
		pannelloStringa.add(stringa);
		pannelloStringa.setBackground(Color.BLACK);
		
		pannelloComponenti = new JPanel();
		pannelloComponenti.setLayout(new GridLayout(2,1));
		pannelloComponenti.add(pannelloStringa);
		pannelloComponenti.add(pannelloPercorso);
		pannelloComponenti.setBackground(Color.BLACK);

		pannelloPrincipale.add(pannelloComponenti,BorderLayout.CENTER);
		
		
	}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento dei
	 * campi di input (in caso contrario notifica l'
	 * utente) ed esegue l'inserimento degli appuntamenti 
	 * (notifica l' utente in caso di errore). </br>
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(arg0.getActionCommand().equals("Carica")) {
			if(agenda!=null) {
				String nomeFile = (testoPercorso.getText().equals("Inserire il percorso del file") || testoPercorso.getText().equals("")) ? null : testoPercorso.getText();
				if(nomeFile==null)
				{
					JOptionPane.showMessageDialog(null, "Inserire un percorso valido\n","Warning",JOptionPane.WARNING_MESSAGE);
				}
				caricamentoDaFile(nomeFile,agenda);
			}
			
			
		}
		
	}

	/**
	 * Metodo che permette di creare un' agenda
	 * leggendo gli appuntamenti contenuti in
	 * un file.</br>
	 * 
	 * @param nomefile determina il percorso assoluto del file
	 * @param agenda determina l'agenda in cui verranno salvati gli appuntamenti
	 */
	private void caricamentoDaFile(String nomeFile, Agenda agenda) {
		Scanner input = null;
		try {
			input =	new Scanner(new File(nomeFile));
		}catch(FileNotFoundException e) 
		{
			JOptionPane.showMessageDialog(null, "Errore!!!\nImpossibile aprire il file.\nIl file non esiste.","Error",JOptionPane.ERROR_MESSAGE);

		}
		//leggo gli appuntamenti e gestisco eventuali errori di formato errato
		boolean lettura = false;
		try {
			lettura = leggiAppuntamentiDaFile(agenda,input);
		}catch (BadFormatException e )
		{
			JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
			dispose();
		}
		
		//controllo che l' inserimento sia avvenuto correttamente
		if(!lettura)
		{
			JOptionPane.showMessageDialog(null, "Errore!!!\nImpossibile leggere il file.\nIl file potrebbe gia' essere stato caricato","Error",JOptionPane.ERROR_MESSAGE);
		}
		else {
			JOptionPane.showMessageDialog(null, "Il file e' stato letto con successo.","Messaggio di conferma",JOptionPane.INFORMATION_MESSAGE);

		}
		
		//chiudo il file
		input.close();
	}
	
	/**
	 * Metodo richiamato dal metodo {@link caricamentoDaFile} 
	 * per la lettura degli appuntamenti da file.
	 * 
	 * @param agenda determina l'agenda in cui verranno salvati gli appuntamenti
	 * @param input determina lo scanner di lettura 
	 * @return <b>true</b> in caso di successo <b>false</b> altrimenti
	 */
	private boolean leggiAppuntamentiDaFile(Agenda agenda,Scanner input) throws BadFormatException			
	{
		if(input==null || agenda==null) return false;
		String [] array = new String[5];
		while(input.hasNextLine())
		{
			//leggo la riga
			String riga = input.nextLine();
			if(riga.isEmpty()) continue;
			System.out.println("Ho letto la riga: " + riga);
			
			//splitto la riga
			try{
				array = riga.split("\t");
			}catch(PatternSyntaxException e) {throw new BadFormatException("Errore durante la lettura da file: formato appuntamento nel file errato");}
			
			//creo l' appuntamento
			String persona = array[0];
			Luogo luogo = new Luogo (array[1]);
			String data = array[2];
			String orario = array[3];
			long durata = Long.parseLong(array[4]);
			Appuntamento appuntamento = new Appuntamento(persona,luogo,data,orario,durata);
			
			//inserisco l'appuntamento
			if(!agenda.inserisciAppuntamento(appuntamento)) return false;
			System.out.println("Inserimento riuscito dell' appuntamento: " + appuntamento.toString());
		}
		return true;
	}
	
	
	
	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

}
