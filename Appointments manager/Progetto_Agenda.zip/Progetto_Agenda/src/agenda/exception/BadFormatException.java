package agenda.exception;

/**
 * Eccezione sollevata quando viene inserito un formato sbagliato in input;</br>
 * estende la classe Exception
 * @see Exception
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 */
@SuppressWarnings("serial")
public class BadFormatException extends Exception {
	/**
	 * Crea un oggetto di tipo BadFormatException richiamando il costruttore 
	 * della classe Exception
	 */
	public BadFormatException() {
		
		super("Formato errato");
	}
	
	/**
	 * Crea un oggetto di tipo BadFormatException richiamando il costruttore 
	 * della classe Exception con il parametro messaggio
	 * @param messaggio stringa che descrive l'anomalia 
	 */
	public BadFormatException(String messaggio) {
		
		super(messaggio);
	}
	

}
