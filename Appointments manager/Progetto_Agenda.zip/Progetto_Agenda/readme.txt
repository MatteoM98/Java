Autori:
	Gabriele Ferrari 
	Matteo Magrì 		 

L'agenda può essere testata in due modi:
- tramite eclipse dopo aver aperto la classe AgendaDemo.java
- come seconda alternativa e più rapida abbiamo aggiunto un file JAR eseguibile chiamato AgendaFM.jar che è possibile aprire digitando da terminale:
	java -jar AgendaFM.jar

All'avvio dell'applicazione viene chiesto il login:
- nome utente: può essere inserito qualsiasi nome che verrà inoltre mostrato nella finestra principale dell'agenda come "Agenda di <nomeUtente>"
- password: la password per accedere è -> agenda2019

La cartella src contiene tutti i sorgenti, mentre la cartella doc contiene il javadoc.
