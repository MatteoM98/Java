package agenda.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import agenda.Luogo;
import agenda.exception.LuogoBadFormatException;

public class TestLuogo {

	Luogo l1=null;
	Luogo l2=null;
	
	@Before
	public void init() {
		
		l1 = new Luogo();
		assertTrue(l1!=null);
		try {
			l2 = new Luogo("Milano, via Centrale,18/A");
		} catch (LuogoBadFormatException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(l2!=null);
	}
	
	@After
	public void reset() {
		l1 = null;
		assertTrue(l1==null);
		l2 = null;
		assertTrue(l2==null);
	}
	
	
	@Test
	public void test() {
		l1.setCitta("Zurigo");
		assertEquals(1,l1.compareTo(l2));
		l1.setIndirizzo("corso Roma");
		assertEquals(1,l1.compareTo(l2));
		l2.setCitta("Zurigo");
		assertEquals(-1,l1.compareTo(l2));
	}

}
