package agenda.exception;

/**
 * Eccezione sollevata quando viene inserito un formato sbagliato in input che riguarda un luogo;</br>
 * estende la classe BadFormatException
 * @see BadFormatException
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 */
@SuppressWarnings("serial")
public class LuogoBadFormatException extends BadFormatException {
	
	/**
	 * Crea un oggetto di tipo LuogoBadFormatException richiamando il costruttore 
	 * della classe BadFormatException
	 */
	public LuogoBadFormatException() {
		
		super("Formato Luogo errato");
	}
	
	/**
	 * Crea un oggetto di tipo LuogoBadFormatException richiamando il costruttore 
	 * della classe BadFormatException con il parametro messaggio
	 * @param messaggio stringa che descrive l'anomalia 
	 */
	public LuogoBadFormatException(String messaggio) {
		
		super(messaggio);
	}
	

}
