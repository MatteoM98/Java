package agenda;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.regex.PatternSyntaxException;

import agenda.exception.AppuntamentoBadFormatException;
import agenda.exception.BadFormatException;
import agenda.exception.LuogoBadFormatException;

/**
 * La classe Agenda è usata per creare agende con i rispettivi campi</br>
 * Ogni oggetto di tipo Agenda ha un nome e un TreeSet di appuntamenti</br>
 * ordinati automaticamente (ordine crescente) per data e ora
 * @author Gabriele Ferrari
 * @author Matteo Magrì
 * 
 */
public class Agenda implements Iterable<Appuntamento>{
	
	
	private String nome;
	private TreeSet <Appuntamento> appuntamenti;
	
	/**
	 * Crea un oggetto di tipo Agenda senza nome
	 */
	public Agenda()
	{
		this("Nessun nome",null);
	}
	
	/**
	 * Crea un oggetto di tipo Agenda</br>
	 * con il nome passato come parametro
	 * @param nome dell'agenda da creare
	 */
	public Agenda(String nome)
	{
		this(nome,null);
	}
	
	/**
	 * Crea un oggetto di tipo Agenda</br>
	 * impostando <b>nome</b> e <b>TreeSet di appuntamenti</b> passati come parametro
	 * @param nome dell'agenda da creare
	 * @param appuntamenti (TreeSet) contiene tutti gli appuntamenti dell'agendaordinati per data e ora
	 */
	public Agenda(String nome, TreeSet<Appuntamento> appuntamenti) 
	{
		this.nome = (nome == null ? "Nessun nome" : nome);
		this.appuntamenti = (appuntamenti == null ? new TreeSet<>() : appuntamenti);
	}
	
	/**
	 * Imposta un nuovo <b>nome</b> per l'agenda passato come parametro
	 * @param nome che si vuole assegnare all'agenda
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	/**
	 * Restituisce il nome dell'agenda
	 * @return il nome dell'agenda
	 */
	public String getNome() {
		return this.nome;
	}
	
	/**
	 * Restituisce l'elenco di appuntamenti (TreeSet)
	 * @return l'elenco di appuntamenti (TreeSet)
	 */
	public TreeSet<Appuntamento> getAppuntamenti() {
		return this.appuntamenti;
	}
	
	/**
	 * Imposta il TreeSet di appuntamenti per l'agenda passato come parametro
	 * @param appuntamenti è un TreeSet di appuntamenti
	 */
	public void setAppuntamenti(TreeSet<Appuntamento> appuntamenti) {
		this.appuntamenti = appuntamenti;
	}
	
	/**
	 * Inserisce l'appuntamento passato come parametro
	 * <ul>
	 * <li>se non è già presente in agenda oppure</li>
	 * <li>se non si sovrappone ad altri appuntamenti</li>
	 * </ul>
	 * @param app è il nuovo appuntamento da inserire nell'agenda
	 * @return <b>true</b> se l'appuntamento viene inserito, <b>false</b> altrimenti
	 */
	public boolean inserisciAppuntamento(Appuntamento app) 
	{
		if(app==null) return false;
		for(Appuntamento a: appuntamenti)
			if(a.sovrapposto(app)) return false;
		appuntamenti.add(app);
		return true;		
	}
	
	/**
	 * Rimuove l'appuntamento <b>app</b> solo se è presente in agenda
	 * @param app è l'appuntamento da rimuovere dall'agenda
	 * @return <b>true</b> se l'appuntamento viene rimosso, <b>false</b> altrimenti
	 */
	public boolean rimuoviAppuntamento(Appuntamento app) 
	{
		if(app==null) return false;
		boolean presente = false;
		try {
			presente = appuntamenti.remove(app);
		}catch (ClassCastException e) {
			return false;
		}
		return presente;	
	}
	
	/**
	 * Permette di modificare un'appuntamento, se questo è presente in agenda</br>
	 * <ul>
	 * <li><b>dataV</b> e <b>oraV</b></br>
	 * sono i parametri per la ricerca dell'appuntamento in agenda e non possono essere <b>null</b></li>
	 * <li><b>dataN</b>, <b>oraN</b>, <b>persona</b>, <b>luogo</b> e <b>durata</b></br>
	 * impostano i rispettivi attributi dell'appuntamento</li>
	 * Vengono modificati solo gli attributi corrispondenti a parametri diversi da <b>null</b>
	 * </ul>
	 * @param dataV parametro per la ricerca di un appuntamento
	 * @param oraV parametro per la ricerca di un appuntamento
	 * @param dataN imposta la nuova data (se null la data non viene modificata)
	 * @param oraN imposta il nuovo orario (se null l'ora non viene modificata)
	 * @param persona imposta la nuova persona (se null la persona non viene modificata)
	 * @param luogo imposta il nuovo luogo (se null il luogo non viene modificato)
	 * @param durata imposta la nuova durata (se null la durata non viene modificata)
	 * @return <b>true</b> se l'appuntamento viene modificato correttamente, <b>false</b> altrimenti
	 */
	public boolean modificaAppuntamento(String dataV, String oraV, String dataN, String oraN, String persona, String luogo,String durata)
	{
		
		Appuntamento a = cercaAppuntamento(dataV,oraV);
		if(a==null) return false;
		Appuntamento b = null;
		String date = null;
		try {
			date = Appuntamento.convertiDataNelFormatoItaliano(a.getData());
		} catch (BadFormatException e) {
			return false;
		}
		
		try {
			b = new Appuntamento (a.getPersona(), a.getLuogo(), date ,a.getOrario().toString(),a.getDurata().toMinutes());
		} catch(AppuntamentoBadFormatException e) {
			return false;
		}
		
		if(dataN!=null) {
			
			try {
				b.setData(dataN);
			}catch(BadFormatException e) {
				return false;
			}
		}
		
		if(oraN!=null) {
			try {
				b.setOrario(oraN);
			}catch (BadFormatException e) {
				return false;
			}
		}
		
		if(persona!=null) b.setPersona(persona);
		
		if(luogo!=null){   
			Luogo l = null;
			try {
				l = new Luogo (luogo);
			} catch (LuogoBadFormatException e ) {
				return false;
			}
			b.setLuogo(l);
		}
		
		if(durata!=null){
			long d = Long.parseLong(durata);
			b.setDurata(d);
		}
		
		for(Appuntamento c : appuntamenti) {
			if(!c.equals(a)) {
				if(b.equals(c) || b.sovrapposto(c)) return false;
			}
		}
		
		appuntamenti.remove(a);
		appuntamenti.add(b);
		return true;
	}
	
	/**
	 * Controlla la presenza di un appuntamento in agenda</br>
	 * la ricerca è svolta confrontando <b>data</b> e <b>ora</b></br>
	 * con i rispettivi campi di ogni appuntamento presente in agenda 
	 * @param data è il parametro per la ricerca (non può essere null)
	 * @param ora è il parametro per la ricerca (non può essere null)
	 * @return l'<b>appuntamento</b> trovato, <b>null</b> altrimenti
	 */
	public Appuntamento cercaAppuntamento(String data,String ora) 
	{
		if(data==null || ora==null) return null;
		String dataConvertita = null;
		try {
			dataConvertita = convertiDataTreeSet(data);
		}catch (BadFormatException e) {
			return null;
		}
		LocalDate date = null;
		LocalTime time = null;
		try {
			date = LocalDate.parse(dataConvertita);
			time = LocalTime.parse(ora);
		} catch (DateTimeParseException e) {
			return null;
		}
		for(Appuntamento a : appuntamenti) 
			if(a.getData().equals(date) && a.getOrario().equals(time)) return a;
		return null;
	}
	
	/**
	 * Cerca la presenza di un appuntamento in agenda</br>
	 * la ricerca è svolta confrontando la <b>persona</b> passata come parametro</br>
	 * con la persona di ogni appuntamento presente in agenda</br>
	 * @param persona è il parametro per la ricerca (non può essere null)
	 * @return un <b>ArrayList di appuntamenti</b> se trova almeno un'appuntamento</br>in base ai parametri di ricerca, <b>null<b> altrimenti
	 */
	public ArrayList<Appuntamento> cercaAppuntamento(String persona) 
	{
		if(persona==null) return null;
		ArrayList<Appuntamento> lista = new ArrayList<Appuntamento>();
		for(Appuntamento a: appuntamenti)
			if(a.getPersona().equalsIgnoreCase(persona) || a.getPersona().toLowerCase().startsWith(persona.toLowerCase()) || a.getPersona().toLowerCase().endsWith(persona.toLowerCase())) {
				lista.add(a);
			}
		return (lista.size()>=1) ? lista : null;
	} 
	
	/**
	 * Stampa gli appuntamenti in ordine per data e ora,</br>
	 * scorrendo il TreeSet di appuntamenti
	 */
	public void stampaPerData()
	{
		for(Appuntamento a: appuntamenti)
			System.out.println(a);
	}
 
	
	/**
	 * Metodo private di servizio che converte la data</br>
	 * dal formato gg-mm-aaaa al formato aaaa-mm-gg
	 * @param data nel formato gg-mm-aaaa da convertire
	 * @return la <b>data convertita</b> nel formato aaaa-mm-gg
	 * @throws BadFormatException denota un errore nel formato dell'input
	 */
	private static String convertiDataTreeSet(String data) throws BadFormatException
	{
		String[] array = new String[3];
		try {
			array = data.split("[- ./]");
		} catch (PatternSyntaxException e ) {
			throw new BadFormatException();
		}
		array[0] = (array[0].length()==1 ? "0"+array[0] : array[0]);
		array[1] = (array[1].length()==1 ? "0"+array[1] : array[1]);
		String giorno = array[0];
		String mese = array[1];
		String anno = array[2];
		String nuovaData =  (anno+"-"+mese+"-"+giorno);
		return nuovaData;
	}
	
	/**
	 * Ridefinisce il toString() di Object adattandolo alla classe Agenda</br>
	 * Restituisce una stringa che rappresenta l'oggetto Agenda
	 * @return la stringa che rappresenta l'oggetto Agenda
	 */
	@Override
    public String toString() 
	{
		 String str = nome+":\n\n";
		 int indice=0;
		 for(Appuntamento i: appuntamenti) {
			 str += ++indice +")\t" + i.toString()+"\n";
		 }
		 return str;
	}
    
	@Override
	public Iterator<Appuntamento> iterator() {
		return appuntamenti.iterator();
	}

	/**
	 * Ridefinisce il metodo equals() di Object adattandolo alla classe Agenda
	 * @param obj oggetto con cui confrontare un'istanza di Agenda
	 * @return <b>true</b> se obj è uguale alla corrente istanza di Agenda, <b>false</b> altrimenti
	 */
	@Override
	public boolean equals(Object obj)
	{
		if(obj==null || obj.getClass()!=this.getClass()) return false;
		Agenda altraAgenda = (Agenda) obj;
		return this.appuntamenti.equals(altraAgenda.appuntamenti) &&
			   this.nome.equals(altraAgenda.getNome());
	}
	
}
