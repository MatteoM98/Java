package agenda.gui;



/**
 * Programma che permette di gestire un' agenda di appuntamenti
 * concedendo all' utente varie operazioni come la creazione di una
 * nuova agenda, l'inserimento di nuovi appuntamenti, la ricerca, 
 * la cancellazione e il salvataggio di appuntamenti su file.</br>
 * Per la realizzazione dell' interfaccia grafica sono state
 * usate le classi <b>Swing</b> e <b>AWT</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
public class AgendaDemo {

	public static void main(String[] args) {
		
	FinestraDiAccesso f = new FinestraDiAccesso();
	f.setVisible(true);
	
	}

}

