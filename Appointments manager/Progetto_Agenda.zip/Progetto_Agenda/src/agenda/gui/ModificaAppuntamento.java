package agenda.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import agenda.Agenda;

/**
 * Permette di modificare un certo appuntamento presente nell' <b>agenda</b>.</br>
 * Per poter catturare particolari eventi sono state implementate
 * le interfacce <b>WindowListener</b> e <b>ActionListener</b>.
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class ModificaAppuntamento extends JFrame implements WindowListener, ActionListener, ItemListener{
	
	public static final int LARGHEZZA = 600;
	public static final int ALTEZZA = 400;
	
	//variabili
	private Agenda agenda;
	
	private JButton modifica;
	
	private JTextField testoNome;
	private JTextField testoLuogo;
	private JTextField testoDurata;
	
	private JPanel dataOraPanel;
	private JPanel upperPanel;
	private JPanel campiPanel;
	private JPanel lowerPanel;
	private JPanel pannelloComboData;
	private JPanel pannelloComboDataModifica;
	private JPanel pannelloComboOra;
	private JPanel pannelloComboOraModifica;
	
	private JCheckBox checkNome;
	private JCheckBox checkLuogo;
	private JCheckBox checkData;
	private JCheckBox checkOra;
	private JCheckBox checkDurata;
	
	private JComboBox <String>  comboGiorni = new JComboBox <String> (CostantiAgenda.GIORNI);
	private JComboBox <String>  comboMesi   = new JComboBox <String> (CostantiAgenda.MESI);
	private JComboBox <String>  comboAnni   = new JComboBox <String> (CostantiAgenda.ANNI);
	private JComboBox <String>  comboOra    = new JComboBox <String> (CostantiAgenda.ORE);
	private JComboBox <String>  comboMinuti = new JComboBox <String> (CostantiAgenda.MINUTI);
	private JComboBox <String>  comboGiorniModifica = new JComboBox <String> (CostantiAgenda.GIORNI);
	private JComboBox <String>  comboMesiModifica   = new JComboBox <String> (CostantiAgenda.MESI);
	private JComboBox <String>  comboAnniModifica   = new JComboBox <String> (CostantiAgenda.ANNI);
	private JComboBox <String>  comboOraModifica    = new JComboBox <String> (CostantiAgenda.ORE);
	private JComboBox <String>  comboMinutiModifica = new JComboBox <String> (CostantiAgenda.MINUTI);
	
	/**
	 * Genera un frame che offre all' utente vari campi
	 * (come pulsanti, text area e checkbox) per ricercare un' appuntamento e modificarlo.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe <b>Agenda</b>
	 * per poterne rendere visibili le modifiche anche alle altre classi.
	 * La modifica può coinvolgere alcuni campi oppure tutti.
	 * 
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public ModificaAppuntamento(Agenda agenda)
	{
		this.agenda = agenda;
		
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Modifica");
		setResizable(false);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));
	
		//vari listener
		addWindowListener(this);
				
				
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new GridLayout(2,1));
		pannelloPrincipale.setBackground(Color.BLACK);
		
		
		//varie label
		JLabel modificaAppuntamento = new JLabel("Quale appuntamento desideri modificare?");
		modificaAppuntamento.setForeground(Color.WHITE);
		modificaAppuntamento.setHorizontalAlignment(SwingConstants.CENTER);
		modificaAppuntamento.setFont(new Font("Arial",Font.PLAIN,14));
		
		JLabel modificaCampi = new JLabel("Quali campi dell' appuntamento vuoi modificare?");
		modificaCampi.setToolTipText("Spunta i campi che intendi modificare");
		modificaCampi.setForeground(Color.WHITE);

		
		JLabel data = new JLabel("*Data: ");
		data.setToolTipText("Inserisci la data dell' appuntamento");
		data.setForeground(Color.WHITE);

		JLabel ora = new JLabel("*Ora: ");
		ora.setToolTipText("Inserisci l' ora dell' appuntamento");
		ora.setForeground(Color.WHITE);


		//pulsante di inserimento
		modifica = new JButton("Modifica");
		modifica.setActionCommand("modify");
		modifica.addActionListener(this);
		getRootPane().setDefaultButton(modifica);
		
		//vari text field
		Font f = new Font("Serif",Font.ITALIC,12);

		testoNome = new JTextField("Scrivi qua il nome");
		testoNome.setBackground(Color.GRAY);
		testoNome.setEditable(false);
		testoNome.setFont(f);
		testoNome.addMouseListener(new SvuotaTesto(testoNome,"Scrivi qua il nome"));
		
		testoLuogo = new JTextField("Citta'[,indirizzo civico]");
		testoLuogo.setBackground(Color.GRAY);
		testoLuogo.setEditable(false);
		testoLuogo.setFont(f);
		testoLuogo.addMouseListener(new SvuotaTesto(testoLuogo,"Citta'[,indirizzo civico]"));
		
		testoDurata = new JTextField("Scrivi la durata in minuti (numero intero)");
		testoDurata.setBackground(Color.GRAY);
		testoDurata.setEditable(false);
		testoDurata.setFont(f);
		testoDurata.addMouseListener(new SvuotaTesto(testoDurata,"Scrivi la durata in minuti (numero intero)"));
		
		//varie checkbox
		checkNome = new JCheckBox("Nome persona");
		checkNome.addItemListener(this);
		checkNome.setForeground(Color.WHITE);
		checkNome.setBackground(Color.BLACK);
		
		checkLuogo = new JCheckBox("Luogo");
		checkLuogo.addItemListener(this);
		checkLuogo.setForeground(Color.WHITE);
		checkLuogo.setBackground(Color.BLACK);

		checkData = new JCheckBox("Data");
		checkData.addItemListener(this);
		checkData.setForeground(Color.WHITE);
		checkData.setBackground(Color.BLACK);

		checkOra = new JCheckBox("Ora");
		checkOra.addItemListener(this);
		checkOra.setForeground(Color.WHITE);
		checkOra.setBackground(Color.BLACK);

		checkDurata = new JCheckBox("Durata");
		checkDurata.addItemListener(this);
		checkDurata.setForeground(Color.WHITE);
		checkDurata.setBackground(Color.BLACK);

		//disabilitazione delle combo box di modifica
		comboGiorniModifica.setEnabled(false);
		comboMesiModifica.setEnabled(false);
		comboAnniModifica.setEnabled(false);
		
		comboOraModifica.setEnabled(false);
		comboMinutiModifica.setEnabled(false);
		
		//vari pannelli
		pannelloComboData = new JPanel();
		pannelloComboData.setLayout(new FlowLayout());
		pannelloComboData.add(comboGiorni);
		pannelloComboData.add(comboMesi);
		pannelloComboData.add(comboAnni);
		pannelloComboData.setBackground(Color.BLACK);

		pannelloComboDataModifica = new JPanel();
		pannelloComboDataModifica.setLayout(new FlowLayout());
		pannelloComboDataModifica.add(comboGiorniModifica);
		pannelloComboDataModifica.add(comboMesiModifica);
		pannelloComboDataModifica.add(comboAnniModifica);
		pannelloComboDataModifica.setBackground(Color.GRAY);

		pannelloComboOra = new JPanel();
		pannelloComboOra.setLayout(new FlowLayout());
		pannelloComboOra.add(comboOra);
		pannelloComboOra.add(comboMinuti);
		pannelloComboOra.setBackground(Color.BLACK);

		pannelloComboOraModifica = new JPanel();
		pannelloComboOraModifica.setLayout(new FlowLayout());
		pannelloComboOraModifica.add(comboOraModifica);
		pannelloComboOraModifica.add(comboMinutiModifica);
		pannelloComboOraModifica.setBackground(Color.GRAY);

		dataOraPanel = new JPanel();
		dataOraPanel.setLayout(new GridLayout(2,2));
		dataOraPanel.add(data);
		dataOraPanel.add(pannelloComboData);
		dataOraPanel.add(ora);
		dataOraPanel.add(pannelloComboOra);
		dataOraPanel.setBackground(Color.BLACK);

		upperPanel = new JPanel();
		upperPanel.setLayout(new BorderLayout());
		upperPanel.add(modificaAppuntamento,"North");
		upperPanel.add(dataOraPanel);
		upperPanel.setBackground(Color.BLACK);

		
		campiPanel = new JPanel();
		campiPanel.setLayout(new GridLayout(5,2));
		campiPanel.add(checkNome);
		campiPanel.add(testoNome);
		campiPanel.add(checkLuogo);
		campiPanel.add(testoLuogo);
		campiPanel.add(checkData);
		campiPanel.add(pannelloComboDataModifica);
		campiPanel.add(checkOra);
		campiPanel.add(pannelloComboOraModifica);
		campiPanel.add(checkDurata);
		campiPanel.add(testoDurata);
		campiPanel.setBackground(Color.BLACK);

		lowerPanel = new JPanel();
		lowerPanel.setLayout(new BorderLayout());
		lowerPanel.add(modificaCampi,"North");
		lowerPanel.add(modifica,"South");
		lowerPanel.add(campiPanel,"Center");
		lowerPanel.setBackground(Color.BLACK);

		//aggiunta dei pannelli nel frame
		pannelloPrincipale.add(upperPanel);
		pannelloPrincipale.add(lowerPanel);
		
		
	}
	
	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica il corretto riempimento dei
	 * campi di input (in caso contrario notifica l'
	 * utente), esegue una ricerca dell' appuntamento
	 * (notifica l'utente nel caso non sia presente) e
	 * lo modifica.</br>
	 * @param arg0 determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
	
		String comando = arg0.getActionCommand();
		boolean successo = false;
		if(comando.equals("modify"))
		{
			if(agenda!=null) {
				//ricavo parametri obbligatori
				String dataV = comboGiorni.getSelectedItem().toString()+"-"+comboMesi.getSelectedItem().toString()+"-"+comboAnni.getSelectedItem().toString();
				String oraV =  comboOra.getSelectedItem().toString()+":"+comboMinuti.getSelectedItem().toString();
				//verifico parametri obbligatori
				if(dataV==null || oraV==null){
					JOptionPane.showMessageDialog(null, "Attenzione!!!\nTutti i campi marcati con '*' sono obbligatori.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
				//ricavo altri parametri di modifica
				String dataN = null;
				String oraN = null;
				if(comboGiorniModifica.isEnabled())
					 dataN = comboGiorniModifica.getSelectedItem().toString()+"-"+comboMesiModifica.getSelectedItem().toString()+"-"+comboAnniModifica.getSelectedItem().toString();
				if(comboOraModifica.isEnabled())
					 oraN =  comboOraModifica.getSelectedItem().toString()+":"+comboMinutiModifica.getSelectedItem().toString();
				String persona = (testoNome.getText().equals("Scrivi qua il nome") || testoNome.getText().equals("")) ? null : testoNome.getText();
				String luogo = (testoLuogo.getText().equals("Citta'[,indirizzo civico]") || testoLuogo.getText().equals("")) ? null : testoLuogo.getText();
				String durata = (testoDurata.getText().equals("Scrivi la durata in minuti (numero intero)") || testoDurata.getText().equals("")) ? null : testoDurata.getText().trim();
				
				//cerco
				successo = agenda.modificaAppuntamento(dataV, oraV, dataN, oraN, persona, luogo, durata);
				//verifico valore di ritorno
				if(successo==false)
				{
					JOptionPane.showMessageDialog(null,"Modifica fallita!"
							+ "\nVerificare la correttezza dei dati inseriti (1)\n"
							+ "Controllare l'effettiva presenza dell'appuntamento che si desidera modificare (2).","Error",JOptionPane.ERROR_MESSAGE);
				}else
				{
					JOptionPane.showMessageDialog(null,"Modifica avvenuta con successo!","Messaggio di conferma",JOptionPane.PLAIN_MESSAGE);
				}
			}
		}
		
	}

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}

	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo item (come la selezione di una checkbox o radio button)
	 * e svolgere particolari azioni.</br>
	 * Il metodo verifica l' eventuale selezionamento o non 
	 * delle varie checkbox e in base a questa informazione
	 * esegue particolari azioni come rendere editabile o meno 
	 * la text area.</br>
	 * @param arg0 determina l'evento di tipo item
	 */
	@Override
	public void itemStateChanged(ItemEvent arg0) {
		
		if(checkNome.isSelected()) {
			testoNome.setBackground(Color.WHITE);
			testoNome.setEditable(true);
		}else if (!checkNome.isSelected())
		{
			testoNome.setBackground(Color.GRAY);
			testoNome.setText("Scrivi qua il nome");
			testoNome.setEditable(false);
		}
		
		if(checkLuogo.isSelected()) {
			testoLuogo.setBackground(Color.WHITE);
			testoLuogo.setEditable(true);
		}else if (!checkLuogo.isSelected())
		{
			testoLuogo.setBackground(Color.GRAY);
			testoLuogo.setText("Citta'[,indirizzo civico]");
			testoLuogo.setEditable(false);
		}
		
		if(checkData.isSelected()) {
			comboGiorniModifica.setEnabled(true);
			comboMesiModifica.setEnabled(true);
			comboAnniModifica.setEnabled(true);
			
		}else if (!checkData.isSelected())
		{
			comboGiorniModifica.setEnabled(false);
			comboMesiModifica.setEnabled(false);
			comboAnniModifica.setEnabled(false);
		}
		
		if(checkOra.isSelected()) {
			comboOraModifica.setEnabled(true);
			comboMinutiModifica.setEnabled(true);
			
		}else if (!checkOra.isSelected())
		{
	     	comboOraModifica.setEnabled(false);
			comboMinutiModifica.setEnabled(false);
		}
		
		if(checkDurata.isSelected()) {
			testoDurata.setBackground(Color.WHITE);
			testoDurata.setEditable(true);
		}else if (!checkDurata.isSelected())
		{
			testoDurata.setBackground(Color.GRAY);
			testoDurata.setText("Scrivi la durata in minuti (numero intero)");
			testoDurata.setEditable(false);
		}	
		
	}

	
}
