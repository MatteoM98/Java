package agenda.gui;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;



import agenda.Agenda;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.*;

/**
 * Permette di visualizzare gli appuntamenti
 * contenuti nell' <b>agenda</b>.</br>
 * @author Matteo Magrì
 * @author Gabriele Ferrari
 */
@SuppressWarnings("serial")
public class VisualizzaAgenda extends JFrame implements WindowListener,ActionListener {

	public static final int LARGHEZZA = 800;
	public static final int ALTEZZA = 600;
	public static final int RIGHE = 600;
	public static final int CARATTERI_PER_RIGA = 600;
	
	private Agenda agenda;
	
	private JButton aggiorna;
	
	private JTextArea testo;
	
	
	private JScrollPane scroll;
	
	
	/**
	 * Genera un frame che offre all' utente la possibilità
	 * di visualizzare gli appuntamenti presenti nell' agenda.</br>
	 * Il parametro <b>agenda</b> permette di usare l' istanza corrente della classe. <b>Agenda</b>
	 *
	 * @param agenda che corrisponde all' istanza in uso nel programma
	 * */
	public VisualizzaAgenda(Agenda agenda)
	{
		this.agenda = agenda;
		
		//vari metodi set
		setSize(LARGHEZZA,ALTEZZA);
		setTitle("Visualizzazione agenda");

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)((dim.getWidth()-this.getWidth())/2),(int)((dim.getHeight()-this.getHeight())/2));

		//vari listener
		addWindowListener(this);
		
		
		//pannello principale
		Container pannelloPrincipale = getContentPane();
		pannelloPrincipale.setLayout(new BorderLayout());
		pannelloPrincipale.setBackground(Color.BLACK);
		
		//creazione pulsante
		aggiorna = new JButton("Aggiorna");
		aggiorna.setActionCommand("update");
		aggiorna.addActionListener(this);
		getRootPane().setDefaultButton(aggiorna);
		
		//creazione text area
		testo = new JTextArea(RIGHE, CARATTERI_PER_RIGA);
		testo.setBackground(Color.DARK_GRAY);
		testo.setForeground(Color.WHITE);
		testo.setEditable(false);
		testo.setText(this.agenda.toString());	
		
		//creazione scrollbar
		scroll = new JScrollPane(testo);
	    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		
		//aggiunta pannelli al frame
	    pannelloPrincipale.add(aggiorna,BorderLayout.SOUTH);
		pannelloPrincipale.add(scroll,BorderLayout.CENTER);
	}
	

	@Override
	public void windowActivated(WindowEvent arg0) {}

	@Override
	public void windowClosed(WindowEvent arg0) {}

	/**
	 * Quando il pulsante di chiusura viene
	 * premuto il metodo cattura l' evento e chiude
	 * solo la finestra corrente senza terminare il programma
	 * @param arg0 determina l'evento di tipo finestra
	 */
	@Override
	public void windowClosing(WindowEvent arg0) {
		dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {}

	@Override
	public void windowDeiconified(WindowEvent arg0) {}

	@Override
	public void windowIconified(WindowEvent arg0) {}

	@Override
	public void windowOpened(WindowEvent arg0) {}


	/**
	 * Metodo che permette di catturare un'
	 * evento di tipo azione (come il click su un pulsante)
	 * e svolgere particolari azioni.</br>
	 * Il metodo stampa il conenuto presente
	 * in agenda nella text area presente. </br>
	 * 
	 * @param e determina l'evento di tipo azione
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if(command.equals("update"))
			testo.setText(agenda.toString());
	}
	
}
